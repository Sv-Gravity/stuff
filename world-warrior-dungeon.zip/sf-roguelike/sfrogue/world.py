"""Dungeon generation and stage-themed room art."""

import random
from collections import deque

import pygame

from .config import (W, H, HUD_H, TOP_WALL, SIDE_WALL, BOTTOM_WALL, PLAY_L, PLAY_R,
                     PLAY_T, PLAY_B, MID_X, MID_Y, DOOR_W, DOOR_H, GRID)
from .sprites import shade, _outline, barrel_sprite

DIRS = {"up": (0, -1), "down": (0, 1), "left": (-1, 0), "right": (1, 0)}
OPPOSITE = {"up": "down", "down": "up", "left": "right", "right": "left"}


# ----------------------------------------------------------------- floors

def draw_floor(s, st, rect, rng):
    fa, fb = st["fa"], st["fb"]
    kind = st["floor"]
    x0, y0, x1, y1 = rect.left, rect.top, rect.right, rect.bottom
    s.fill(fa, rect)
    if kind == "planks":
        for i, y in enumerate(range(y0, y1, 8)):
            col = fa if i % 2 else fb
            s.fill(col, (x0, y, rect.width, 8))
            s.fill(shade(fa, 0.6), (x0, y + 7, rect.width, 1))
            off = (i * 23) % 48
            for x in range(x0 - off, x1, 48):
                s.fill(shade(fa, 0.6), (x, y, 1, 7))
            for _ in range(10):
                s.fill(shade(col, 0.85), (rng.randrange(x0, x1), y + rng.randrange(1, 6), 3, 1))
    elif kind in ("tiles", "terracotta"):
        size = 16 if kind == "tiles" else 12
        for y in range(y0, y1, size):
            for x in range(x0, x1, size):
                col = fa if ((x // size + y // size) % 2 == 0 or kind == "terracotta") else fb
                if kind == "terracotta":
                    col = shade(fa, rng.uniform(0.88, 1.05))
                s.fill(col, (x, y, size, size))
                s.fill(shade(fa, 0.65), (x, y + size - 1, size, 1))
                s.fill(shade(fa, 0.65), (x + size - 1, y, 1, size))
                s.fill(shade(col, 1.12), (x + 1, y + 1, size - 3, 1))
    elif kind == "stone":
        for i, y in enumerate(range(y0, y1, 9)):
            x = x0 - rng.randrange(0, 12)
            while x < x1:
                w = rng.randrange(10, 22)
                s.fill(shade(fa if rng.random() < 0.5 else fb, rng.uniform(0.9, 1.08)), (x, y, w - 1, 8))
                s.fill(shade(fa, 1.15), (x, y, w - 2, 1))
                x += w
            s.fill(shade(fb, 0.55), (x0, y + 8, rect.width, 1))
    elif kind == "grass":
        for _ in range(rect.width * rect.height // 30):
            x, y = rng.randrange(x0, x1), rng.randrange(y0, y1)
            s.fill(fb if rng.random() < 0.6 else shade(fa, 1.2), (x, y, 1, 2))
        for _ in range(12):  # dirt path patches
            x, y = rng.randrange(x0, x1), rng.randrange(y0, y1)
            pygame.draw.ellipse(s, shade(fb, 0.9), (x, y, rng.randrange(8, 20), rng.randrange(4, 8)))
    elif kind == "metal":
        for y in range(y0, y1, 16):
            for x in range(x0, x1, 32):
                s.fill(fb, (x, y, 31, 15))
                for k in range(0, 31, 4):
                    s.fill(shade(fb, 1.15), (x + k, y + (k // 4) % 2 * 4 + 3, 2, 1))
                for rx, ry in ((2, 2), (28, 2), (2, 12), (28, 12)):
                    s.fill(shade(fa, 1.35), (x + rx, y + ry, 1, 1))
    elif kind == "carpet":
        for y in range(y0, y1, 16):
            for x in range(x0, x1, 16):
                cx, cy = x + 8, y + 8
                pygame.draw.polygon(s, fb, [(cx, cy - 6), (cx + 6, cy), (cx, cy + 6), (cx - 6, cy)])
                s.fill((220, 170, 60), (cx, cy, 1, 1))
                s.fill((200, 150, 50), (x, y, 1, 1))
    elif kind == "concrete":
        for _ in range(rect.width * rect.height // 25):
            x, y = rng.randrange(x0, x1), rng.randrange(y0, y1)
            s.fill(shade(fa, rng.uniform(0.85, 1.1)), (x, y, 2, 1))
        for x in range(x0, x1, 64):
            s.fill(shade(fa, 0.7), (x, y0, 1, rect.height))
        s.fill(st["acc"], (x0, (y0 + y1) // 2 - 1, rect.width, 2))
        for x in range(x0 + 6, x1, 24):
            s.fill(st["acc"], (x, y1 - 14, 12, 2))


# ----------------------------------------------------------------- walls

def draw_top_wall(s, st, rng):
    y0, h = HUD_H, TOP_WALL
    wc, wd, acc = st["wc"], st["wd"], st["acc"]
    style = st["wall"]
    s.fill(wc, (0, y0, W, h))
    if style == "castle":
        s.fill((70, 80, 110), (0, y0, W, 6))
        for x in range(0, W, 8):
            pygame.draw.circle(s, (50, 60, 90), (x + 4, y0 + 6), 4)
        for x in range(0, W, 40):
            s.fill(wd, (x, y0 + 6, 4, h - 6))
        s.fill(wd, (0, y0 + h - 4, W, 4))
        for x in range(20, W, 80):
            pygame.draw.ellipse(s, acc, (x, y0 + 9, 7, 9))
            s.fill((250, 220, 120), (x + 2, y0 + 12, 3, 3))
    elif style == "harbor":
        for y in range(y0, y0 + h - 5, 3):
            s.fill(shade(wc, 0.8 + 0.1 * ((y // 3) % 3)), (0, y, W, 3))
        for _ in range(30):
            s.fill((200, 230, 255), (rng.randrange(W), rng.randrange(y0, y0 + h - 6), 4, 1))
        s.fill((140, 40, 40), (200, y0 + 2, 100, 10))   # a ship's hull out on the water
        s.fill((230, 230, 230), (230, y0, 40, 3))
        s.fill(wd, (0, y0 + h - 5, W, 5))
        for x in range(0, W, 20):
            s.fill(shade(wd, 0.7), (x, y0 + h - 9, 3, 9))
    elif style == "bath":
        for y in range(y0, y0 + h):
            s.fill(shade(wc, 0.85 + (y - y0) / h * 0.3), (0, y, W, 1))
        pygame.draw.polygon(s, (70, 100, 170), [(60, y0 + h - 4), (110, y0 + 2), (160, y0 + h - 4)])
        pygame.draw.polygon(s, (245, 245, 250), [(97, y0 + 9), (110, y0 + 2), (123, y0 + 9)])
        pygame.draw.circle(s, (240, 90, 60), (250, y0 + 8), 5)
        s.fill(wd, (0, y0 + h - 4, W, 4))
    elif style == "market":
        x = 0
        while x < W:
            w = rng.randrange(36, 60)
            col = wc if (x // 40) % 2 == 0 else wd
            s.fill(col, (x, y0, w - 2, h))
            s.fill(acc, (x + 4, y0 + 3, w - 10, 6))
            for k in range(x + 6, x + w - 8, 5):
                s.fill(shade(col, 0.6), (k, y0 + 4, 3, 4))
            s.fill((30, 25, 25), (x + 6, y0 + 12, w - 14, h - 12))
            x += w
        for x in range(10, W, 50):
            pygame.draw.ellipse(s, (230, 50, 40), (x, y0 + 1, 6, 8))
    elif style == "jungle":
        s.fill(wd, (0, y0 + 10, W, h - 10))
        for _ in range(25):
            s.fill((140, 190, 230), (rng.randrange(W), rng.randrange(y0 + 11, y0 + h - 2), 5, 1))
        for x in range(-6, W, 14):
            pygame.draw.circle(s, shade(wc, rng.uniform(0.8, 1.2)), (x, y0 + 5), 9)
        s.fill((120, 85, 50), (0, y0 + h - 3, W, 3))
    elif style == "factory":
        s.fill(shade(wc, 0.8), (0, y0, W, h))
        for y in (y0 + 4, y0 + 11):
            s.fill((120, 115, 120), (0, y, W, 3))
            s.fill((170, 165, 170), (0, y, W, 1))
        for x in range(0, W, 16):
            s.fill(acc if (x // 16) % 2 else (30, 30, 30), (x, y0 + h - 4, 16, 4))
        for x in range(30, W, 90):
            pygame.draw.circle(s, (200, 200, 190), (x, y0 + 9), 4)
            s.fill(wd, (x, y0 + 7, 1, 3))
    elif style == "hangar":
        s.fill(wd, (0, y0, W, 8))
        for x in range(0, W, 4):
            s.fill(shade(wc, 0.85 if x % 8 else 1.05), (x, y0 + 8, 4, h - 8))
        s.fill((80, 85, 80), (90, y0 + 3, 140, 4))      # parked jet on the apron
        pygame.draw.polygon(s, (80, 85, 80), [(150, y0 + 5), (175, y0 - 0), (185, y0 + 5)])
        s.fill(acc, (0, y0 + h - 3, W, 1))
    elif style == "temple":
        for x in range(0, W, 32):
            pygame.draw.ellipse(s, wd, (x + 6, y0 + 3, 20, 26))
            s.fill(wd, (x + 6, y0 + 15, 20, h - 15))
        for x in (50, 240):
            pygame.draw.ellipse(s, acc, (x, y0 + 5, 26, 13))
            s.fill(acc, (x + 4, y0 + 15, 4, 6))
            s.fill(acc, (x + 18, y0 + 15, 4, 6))
            s.fill(acc, (x - 2, y0 + 8, 4, 10))
        s.fill(shade(wc, 0.7), (0, y0 + h - 3, W, 3))
    elif style == "neon":
        for x in range(0, W, 2):
            if rng.random() < 0.15:
                s.fill((255, 240, 150), (x, y0 + rng.randrange(2, h - 4), 1, 1))
        s.fill(wd, (0, y0 + 3, W, 1))
        s.fill(acc, (0, y0 + h - 6, W, 1))
        for x in range(20, W, 70):
            s.fill(wd, (x, y0 + 7, 30, 1))
            s.fill(wd, (x, y0 + 12, 30, 1))
            s.fill(acc, (x + 4, y0 + 8, 1, 4))
            s.fill(acc, (x + 24, y0 + 8, 1, 4))
    elif style == "fence":
        for _ in range(140):
            s.fill(rng.choice([(200, 60, 60), (230, 200, 120), (80, 120, 200), (240, 240, 240),
                               (90, 60, 40)]), (rng.randrange(W), rng.randrange(y0, y0 + h - 4), 2, 3))
        for x in range(-h, W, 6):
            pygame.draw.line(s, wd, (x, y0), (x + h, y0 + h), 1)
            pygame.draw.line(s, wd, (x + h, y0), (x, y0 + h), 1)
        s.fill((70, 50, 40), (0, y0 + h - 4, W, 4))
    elif style == "buddha":
        for y in range(y0, y0 + h):
            s.fill(shade(wc, 1.1 - (y - y0) / h * 0.35), (0, y, W, 1))
        pygame.draw.ellipse(s, wd, (40, y0 + 6, 240, 14))
        pygame.draw.circle(s, wd, (270, y0 + 8), 8)
        s.fill(shade(wd, 0.75), (40, y0 + 16, 240, 3))
        for x in (14, 300):
            s.fill((100, 70, 40), (x, y0 + 4, 3, h - 4))
            pygame.draw.ellipse(s, acc, (x - 7, y0, 17, 8))
        s.fill((150, 150, 140), (0, y0 + h - 3, W, 3))
    elif style == "shadaloo":
        for y in range(y0, y0 + h, 7):
            for x in range(-((y // 7) % 2) * 10, W, 20):
                s.fill(shade(wc, rng.uniform(0.85, 1.1)), (x, y, 19, 6))
        for x in range(28, W, 64):
            s.fill(wd, (x, y0, 14, h - 4))
            s.fill(acc, (x + 5, y0 + 7, 4, 4))
            pygame.draw.polygon(s, wd, [(x, y0 + h - 4), (x + 7, y0 + h), (x + 14, y0 + h - 4)])
    # bottom lip of the wall
    s.fill(shade(wc, 0.45), (0, y0 + h - 1, W, 1))


def render_room_background(st, room):
    rng = random.Random(room.seed)
    s = pygame.Surface((W, H))
    s.fill((0, 0, 0))
    draw_floor(s, st, pygame.Rect(0, PLAY_T, W, H - PLAY_T), rng)
    # contact shadow under the top wall
    shadow = pygame.Surface((W, 6), pygame.SRCALPHA)
    shadow.fill((0, 0, 0, 70))
    s.blit(shadow, (0, PLAY_T))
    for pool in room.pools:
        col = st.get("pool", (70, 140, 200))
        pygame.draw.rect(s, shade(col, 0.6), pool.inflate(4, 4), border_radius=4)
        pygame.draw.rect(s, col, pool, border_radius=4)
        for _ in range(pool.width * pool.height // 60):
            s.fill(shade(col, 1.3), (rng.randrange(pool.left + 2, pool.right - 4),
                                     rng.randrange(pool.top + 2, pool.bottom - 2), 4, 1))
    draw_top_wall(s, st, rng)
    side = shade(st["wc"], 0.55)
    s.fill(side, (0, PLAY_T, SIDE_WALL, H - PLAY_T))
    s.fill(side, (W - SIDE_WALL, PLAY_T, SIDE_WALL, H - PLAY_T))
    s.fill(shade(st["wc"], 0.35), (0, PLAY_B, W, BOTTOM_WALL))
    s.fill(shade(side, 1.3), (SIDE_WALL - 1, PLAY_T, 1, PLAY_B - PLAY_T))
    s.fill(shade(side, 1.3), (W - SIDE_WALL, PLAY_T, 1, PLAY_B - PLAY_T))
    # door openings
    dark = (12, 10, 16)
    frame = shade(st["wd"], 0.8)
    for d in room.doors:
        r = door_rect(d)
        s.fill(frame, r.inflate(4, 4).clip(pygame.Rect(0, HUD_H, W, H - HUD_H)))
        s.fill(dark, r)
    return s


def door_rect(d):
    if d == "up":
        return pygame.Rect(MID_X - DOOR_W // 2, HUD_H + 4, DOOR_W, TOP_WALL - 4)
    if d == "down":
        return pygame.Rect(MID_X - DOOR_W // 2, PLAY_B, DOOR_W, BOTTOM_WALL)
    if d == "left":
        return pygame.Rect(0, MID_Y - DOOR_H // 2, SIDE_WALL, DOOR_H)
    return pygame.Rect(W - SIDE_WALL, MID_Y - DOOR_H // 2, SIDE_WALL, DOOR_H)


def draw_door_bars(s, d, color):
    r = door_rect(d)
    if d in ("up", "down"):
        for x in range(r.left + 2, r.right - 1, 5):
            s.fill(color, (x, r.top, 2, r.height))
        s.fill(shade(color, 0.7), (r.left, r.top + r.height // 2, r.width, 2))
    else:
        for y in range(r.top + 2, r.bottom - 1, 5):
            s.fill(color, (r.left, y, r.width, 2))
        s.fill(shade(color, 0.7), (r.left + r.width // 2, r.top, 2, r.height))


# ----------------------------------------------------------------- obstacles

_obst_cache = {}


def obstacle_image(kind, st):
    key = (kind, st["name"])
    if key in _obst_cache:
        return _obst_cache[key]
    acc, wd = st["acc"], st["wd"]
    if kind == "lantern":       # stone toro lantern
        s = pygame.Surface((16, 26), pygame.SRCALPHA)
        g = (150, 150, 145)
        s.fill(shade(g, 0.8), (5, 14, 6, 10))
        s.fill(g, (2, 22, 12, 4))
        s.fill(g, (1, 4, 14, 3))
        s.fill(g, (3, 7, 10, 7))
        s.fill((250, 210, 100), (6, 9, 4, 3))
        pygame.draw.polygon(s, shade(g, 0.9), [(0, 4), (8, 0), (15, 4)])
    elif kind == "crate":
        s = pygame.Surface((18, 20), pygame.SRCALPHA)
        c = (170, 120, 60)
        s.fill(c, (0, 4, 18, 16))
        s.fill(shade(c, 1.2), (0, 0, 18, 5))
        pygame.draw.line(s, shade(c, 0.65), (1, 5), (16, 19), 2)
        s.fill(shade(c, 0.65), (0, 5, 18, 1))
    elif kind == "bucket":
        s = pygame.Surface((14, 14), pygame.SRCALPHA)
        c = (160, 110, 60)
        pygame.draw.polygon(s, c, [(1, 3), (13, 3), (11, 13), (3, 13)])
        s.fill((90, 90, 90), (2, 6, 10, 1))
        pygame.draw.ellipse(s, (90, 160, 220), (1, 1, 12, 4))
    elif kind == "palm":
        s = pygame.Surface((26, 34), pygame.SRCALPHA)
        s.fill((120, 85, 45), (11, 8, 5, 26))
        for k in range(10, 34, 4):
            s.fill((95, 65, 35), (11, k, 5, 1))
        for dx, dy in ((-11, 3), (11, 3), (-7, -2), (7, -2)):
            pygame.draw.ellipse(s, (50, 140, 60), (13 + dx - 6 if dx < 0 else 13, 3 + dy, 13, 6))
    elif kind == "drum":
        s = pygame.Surface((14, 20), pygame.SRCALPHA)
        c = acc if st["name"] != "STEEL FACTORY" else (60, 110, 70)
        pygame.draw.ellipse(s, c, (0, 14, 14, 6))
        s.fill(c, (0, 3, 14, 14))
        pygame.draw.ellipse(s, shade(c, 1.25), (0, 0, 14, 6))
        s.fill(shade(c, 0.7), (0, 9, 14, 2))
    elif kind == "pillar":
        s = pygame.Surface((18, 40), pygame.SRCALPHA)
        c = acc if st["name"] == "MAHARAJA TEMPLE" else (110, 95, 120)
        s.fill(c, (3, 4, 12, 32))
        s.fill(shade(c, 1.25), (5, 4, 3, 32))
        s.fill(shade(c, 0.7), (12, 4, 3, 32))
        s.fill(shade(c, 1.1), (0, 0, 18, 5))
        s.fill(shade(c, 1.1), (0, 35, 18, 5))
    elif kind == "slot":
        s = pygame.Surface((16, 28), pygame.SRCALPHA)
        s.fill((200, 30, 60), (0, 4, 16, 24))
        s.fill((250, 220, 80), (0, 0, 16, 5))
        s.fill((20, 20, 30), (3, 8, 10, 7))
        for i, c in enumerate(((255, 60, 60), (255, 220, 60), (80, 220, 255))):
            s.fill(c, (4 + i * 3, 10, 2, 3))
        s.fill((200, 200, 210), (14, 10, 2, 8))
    elif kind == "table":
        s = pygame.Surface((22, 18), pygame.SRCALPHA)
        c = (120, 75, 45)
        pygame.draw.ellipse(s, c, (0, 2, 22, 8))
        s.fill(shade(c, 0.7), (9, 8, 4, 10))
        s.fill((200, 40, 40), (6, 3, 3, 4))
        s.fill((240, 230, 200), (13, 4, 3, 3))
    elif kind == "statue":
        s = pygame.Surface((18, 30), pygame.SRCALPHA)
        c = (200, 165, 60)
        s.fill((140, 135, 125), (1, 22, 16, 8))
        pygame.draw.ellipse(s, c, (2, 9, 14, 15))
        pygame.draw.circle(s, c, (9, 6), 5)
        s.fill(shade(c, 1.2), (8, 0, 2, 3))
    else:
        s = pygame.Surface((16, 16), pygame.SRCALPHA)
        s.fill(wd, (0, 0, 16, 16))
    img = _outline(s)
    _obst_cache[key] = img
    return img


class Obstacle:
    def __init__(self, img, x, y, fw, fh):
        self.img = img
        self.rect = pygame.Rect(int(x - fw / 2), int(y - fh), int(fw), int(fh))  # footprint

    @property
    def sort_y(self):
        return self.rect.bottom

    def draw(self, surf, ox=0, oy=0):
        surf.blit(self.img, (self.rect.centerx - self.img.get_width() // 2 + ox,
                             self.rect.bottom - self.img.get_height() + 1 + oy))


class Breakable:
    """A barrel that can be smashed for loot."""

    def __init__(self, x, y):
        self.x, self.y = float(x), float(y)
        self.hp = 10
        self.img = barrel_sprite()
        self.flash = 0
        self.half_w = 7
        self.dead = False
        self.hit_by = set()

    @property
    def rect(self):
        return pygame.Rect(int(self.x - 7), int(self.y - 5), 14, 6)

    @property
    def sort_y(self):
        return self.y

    def draw(self, surf, ox=0, oy=0):
        jig = 1 if self.flash % 2 else 0
        surf.blit(self.img, (int(self.x) - 8 + jig + ox, int(self.y) - 19 + oy))
        if self.flash:
            self.flash -= 1


# ----------------------------------------------------------------- rooms

class Room:
    def __init__(self, pos, kind, seed):
        self.pos = pos
        self.kind = kind          # start, fight, treasure, boss
        self.seed = seed
        self.doors = []
        self.visited = False
        self.cleared = kind in ("start", "treasure")
        self.obstacles = []
        self.pools = []
        self.barrels = []
        self.items = []           # persistent pickups left in the room
        self.treasure_taken = False
        self.bg = None

    def build_layout(self, st):
        rng = random.Random(self.seed)
        lane_x = pygame.Rect(MID_X - 26, PLAY_T, 52, PLAY_B - PLAY_T)
        lane_y = pygame.Rect(PLAY_L, MID_Y - 20, PLAY_R - PLAY_L, 40)

        def free(r):
            return not r.colliderect(lane_x) and not r.colliderect(lane_y) and \
                all(not r.colliderect(o.rect.inflate(10, 10)) for o in self.obstacles) and \
                all(not r.colliderect(p.inflate(8, 8)) for p in self.pools)

        if self.kind in ("start", "boss", "treasure"):
            template = "pillars4" if self.kind == "boss" and rng.random() < 0.5 else "empty"
        else:
            template = rng.choice(["empty", "pillars4", "pillars2", "scatter", "scatter",
                                   "pool" if "pool" in st else "scatter"])
        kind = st["obst"]
        img = obstacle_image(kind, st)
        fw, fh = img.get_width() - 2, 8
        if template == "pillars4":
            for x in (78, W - 78):
                for y in (PLAY_T + 26, PLAY_B - 18):
                    self.obstacles.append(Obstacle(img, x, y, fw, fh))
        elif template == "pillars2":
            y = rng.choice([PLAY_T + 26, PLAY_B - 18])
            for x in (78, W - 78):
                self.obstacles.append(Obstacle(img, x, y, fw, fh))
        elif template == "scatter":
            for _ in range(rng.randint(2, 5)):
                for _try in range(20):
                    x = rng.randrange(PLAY_L + 20, PLAY_R - 20)
                    y = rng.randrange(PLAY_T + 14, PLAY_B - 6)
                    o = Obstacle(img, x, y, fw, fh)
                    if free(o.rect):
                        self.obstacles.append(o)
                        break
        elif template == "pool":
            for _ in range(rng.randint(1, 2)):
                for _try in range(20):
                    w, h = rng.randrange(40, 70), rng.randrange(20, 32)
                    r = pygame.Rect(rng.randrange(PLAY_L + 8, PLAY_R - w - 8),
                                    rng.randrange(PLAY_T + 8, PLAY_B - h - 6), w, h)
                    if free(r):
                        self.pools.append(r)
                        break
        if self.kind == "fight" and rng.random() < 0.55:
            for _ in range(rng.randint(1, 3)):
                for _try in range(20):
                    x = rng.randrange(PLAY_L + 16, PLAY_R - 16)
                    y = rng.randrange(PLAY_T + 12, PLAY_B - 4)
                    b = Breakable(x, y)
                    if free(b.rect.inflate(6, 6)):
                        self.barrels.append(b)
                        break

    def solids(self):
        """Rects that block walking."""
        out = [o.rect for o in self.obstacles]
        out.extend(self.pools)
        out.extend(b.rect for b in self.barrels if not b.dead)
        return out


class Floor:
    def __init__(self, index, stage_key, stage, seed):
        self.index = index
        self.stage_key = stage_key
        self.stage = stage
        rng = random.Random(seed)
        n_rooms = min(12, 6 + index // 2)
        start = (GRID // 2, GRID // 2)
        cells = {start}
        order = [start]
        tries = 0
        while len(cells) < n_rooms and tries < 2000:
            tries += 1
            base = rng.choice(order)
            d = rng.choice(list(DIRS.values()))
            nb = (base[0] + d[0], base[1] + d[1])
            if not (0 <= nb[0] < GRID and 0 <= nb[1] < GRID) or nb in cells:
                continue
            neighbours = sum((nb[0] + v[0], nb[1] + v[1]) in cells for v in DIRS.values())
            if neighbours > 1 and rng.random() < 0.8:
                continue
            cells.add(nb)
            order.append(nb)
        dist = self._bfs(cells, start)
        dead_ends = [c for c in cells if c != start and self._degree(cells, c) == 1]
        boss = max(dead_ends or list(cells - {start}), key=lambda c: dist[c])
        others = [c for c in dead_ends if c != boss] or [c for c in cells if c not in (start, boss)]
        treasure = rng.choice(others) if others else None
        self.rooms = {}
        for c in order:
            kind = "fight"
            if c == start:
                kind = "start"
            elif c == boss:
                kind = "boss"
            elif c == treasure:
                kind = "treasure"
            room = Room(c, kind, rng.randrange(1 << 30))
            room.doors = [name for name, v in DIRS.items() if (c[0] + v[0], c[1] + v[1]) in cells]
            room.build_layout(stage)
            self.rooms[c] = room
        self.start = start
        self.boss_pos = boss

    @staticmethod
    def _degree(cells, c):
        return sum((c[0] + v[0], c[1] + v[1]) in cells for v in DIRS.values())

    @staticmethod
    def _bfs(cells, start):
        dist = {start: 0}
        q = deque([start])
        while q:
            c = q.popleft()
            for v in DIRS.values():
                nb = (c[0] + v[0], c[1] + v[1])
                if nb in cells and nb not in dist:
                    dist[nb] = dist[c] + 1
                    q.append(nb)
        return dist

    def background(self, room):
        if room.bg is None:
            room.bg = render_room_background(self.stage, room)
        return room.bg
