"""Chiptune sound effects and music, synthesised at startup (no audio files).

If the machine has no sound device the game simply runs silently.
"""

import random
from array import array

import pygame


def midi(n):
    return 440.0 * 2 ** ((n - 69) / 12.0)


NOTE = {"C": 0, "C#": 1, "D": 2, "D#": 3, "E": 4, "F": 5, "F#": 6,
        "G": 7, "G#": 8, "A": 9, "A#": 10, "B": 11}


def parse(seq):
    """'A4 . C5 -' -> list of midi numbers / None (rest) / '-' (hold)."""
    out = []
    for tok in seq.split():
        if tok == ".":
            out.append(None)
        elif tok == "-":
            out.append("-")
        else:
            name, octave = tok[:-1], int(tok[-1])
            out.append(12 * (octave + 1) + NOTE[name])
    return out


# Original tunes in a 90s arcade style.
TRACKS = {
    "stage": dict(
        bpm=150,
        lead="A4 - C5 - E5 D5 C5 B4  G4 - B4 - D5 C5 B4 G4  "
             "F4 - A4 - C5 B4 A4 C5  E5 - - - E5 D5 C5 B4  "
             "A4 - C5 - E5 D5 E5 G5  A5 - G5 - E5 - D5 -  "
             "C5 D5 E5 - D5 C5 B4 -  A4 - - - . . E4 G#4",
        bass="A2 A2 A3 A2 A2 A3 A2 G2  G2 G2 G3 G2 G2 G3 G2 G2  "
             "F2 F2 F3 F2 F2 F3 F2 F2  E2 E2 E3 E2 G#2 G#2 B2 E3  "
             "A2 A2 A3 A2 A2 A3 A2 G2  F2 F2 F3 F2 F2 F3 F2 F2  "
             "C3 C3 C4 C3 G2 G2 G3 G2  E2 E2 E3 E2 E2 E3 G#2 B2",
        drums="k h s h k k s h " * 8,
    ),
    "boss": dict(
        bpm=172,
        lead="E5 E5 G5 E5 F#5 E5 D5 B4  C5 C5 E5 C5 D5 C5 B4 A4  "
             "B4 - D5 - F#5 - B5 A5  G5 - F#5 - E5 - D#5 -  "
             "E5 E5 G5 E5 F#5 E5 D5 B4  C5 C5 E5 C5 D5 E5 F#5 G5  "
             "A5 - G5 - F#5 - E5 -  B4 - D#5 - F#5 - B5 -",
        bass="E2 E3 E2 E3 E2 E3 D3 E3  C2 C3 C2 C3 C2 C3 D3 C3  "
             "B1 B2 B1 B2 B1 B2 A2 B2  E2 E3 E2 E3 B1 B2 D#2 B2  "
             "E2 E3 E2 E3 E2 E3 D3 E3  C2 C3 C2 C3 C2 C3 D3 C3  "
             "A1 A2 A1 A2 C2 C3 D2 D3  B1 B2 B1 B2 B1 B2 D#3 F#3",
        drums="k h s h k h s s " * 8,
    ),
    "title": dict(
        bpm=126,
        lead="E5 - D5 - C5 - D5 -  E5 - G5 - E5 - D5 -  "
             "C5 - A4 - C5 - D5 -  E5 - - - - - . .  "
             "A5 - G5 - E5 - G5 -  A5 - B5 - A5 - G5 -  "
             "E5 - D5 - C5 - D5 -  E5 - - - - - . .",
        bass="A2 . A3 . A2 . A3 .  C3 . C4 . C3 . C4 .  "
             "F2 . F3 . F2 . F3 .  E2 . E3 . E2 . E3 .  "
             "A2 . A3 . A2 . A3 .  G2 . G3 . G2 . G3 .  "
             "F2 . F3 . G2 . G3 .  A2 . A3 . A2 . A3 .",
        drums="k . h . s . h . " * 8,
    ),
}


class Audio:
    def __init__(self, enabled=True):
        self.ok = False
        self.sounds = {}
        self.music = {}
        self.current = None
        self.music_volume = 0.55
        if not enabled:
            return
        try:
            if not pygame.mixer.get_init():
                pygame.mixer.init(22050, -16, 1, 512)
            freq, size, channels = pygame.mixer.get_init()
            if size != -16:
                raise RuntimeError("unsupported sample format %r" % size)
            self.sr = freq
            self.channels = channels
            pygame.mixer.set_num_channels(16)
            pygame.mixer.set_reserved(1)
            self.music_chan = pygame.mixer.Channel(0)
            self.ok = True
        except Exception as exc:  # no sound card, headless, etc.
            print("Sound disabled:", exc)
            self.ok = False
            return
        self._build_sfx()

    # ----------------------------------------------------------- synthesis
    def _to_sound(self, samples):
        data = array("h", (int(max(-1.0, min(1.0, v)) * 30000) for v in samples))
        if self.channels == 2:
            st = array("h", bytes(len(data) * 4))
            st[0::2] = data
            st[1::2] = data
            data = st
        return pygame.mixer.Sound(buffer=data)

    def _tone(self, f0, f1, dur, vol=0.3, wave="square", duty=0.5, decay=1.0):
        sr = self.sr
        n = int(sr * dur)
        out = [0.0] * n
        ph = 0.0
        hold = 0.0
        rnd = random.random
        for i in range(n):
            t = i / n
            f = f0 + (f1 - f0) * t
            ph += f / sr
            if ph >= 1.0:
                ph -= int(ph)
                hold = rnd() * 2 - 1
            if wave == "square":
                v = 1.0 if ph < duty else -1.0
            elif wave == "tri":
                v = 4 * abs(ph - 0.5) - 1
            else:  # pitched noise
                v = hold
            out[i] = v * vol * (1 - t) ** decay
        return out

    @staticmethod
    def _mix(*parts):
        n = max(len(p) for p in parts)
        out = [0.0] * n
        for p in parts:
            for i, v in enumerate(p):
                out[i] += v
        return out

    def _build_sfx(self):
        T = self._tone
        cat = lambda *ps: [v for p in ps for v in p]
        defs = {
            "swing": T(900, 300, 0.05, 0.12, "noise"),
            "punch": self._mix(T(3000, 600, 0.07, 0.35, "noise"), T(180, 60, 0.07, 0.3)),
            "kick": self._mix(T(2000, 300, 0.10, 0.4, "noise"), T(140, 40, 0.1, 0.35)),
            "heavy": self._mix(T(2500, 200, 0.16, 0.45, "noise"), T(120, 30, 0.16, 0.4)),
            "hadouken": self._mix(T(220, 700, 0.22, 0.22, "square", 0.25, 0.4),
                                  T(4000, 1500, 0.28, 0.18, "noise", decay=0.6)),
            "fireball": self._mix(T(300, 500, 0.18, 0.18, "square", 0.25, 0.5),
                                  T(3000, 1200, 0.2, 0.12, "noise")),
            "hurt": T(600, 150, 0.16, 0.25, "square", 0.3),
            "ko": cat(T(500, 80, 0.5, 0.3, "square", 0.5, 0.6)),
            "pickup": cat(T(660, 660, 0.05, 0.2), T(880, 880, 0.05, 0.2), T(1320, 1320, 0.08, 0.2)),
            "coin": cat(T(990, 990, 0.04, 0.18), T(1480, 1480, 0.12, 0.18)),
            "door": cat(T(200, 200, 0.06, 0.25), T(150, 150, 0.1, 0.25)),
            "slam": self._mix(T(800, 100, 0.2, 0.35, "noise"), T(90, 40, 0.2, 0.35)),
            "select": T(880, 880, 0.04, 0.18, "square", 0.25),
            "confirm": cat(T(523, 523, 0.06, 0.2), T(784, 784, 0.06, 0.2), T(1046, 1046, 0.12, 0.2)),
            "car": self._mix(T(1800, 200, 0.22, 0.5, "noise", decay=0.7), T(100, 40, 0.22, 0.35)),
            "glass": T(6000, 3000, 0.25, 0.3, "noise", decay=0.5),
            "stairs": cat(*[T(f, f, 0.06, 0.2, "square", 0.25) for f in (392, 523, 659, 784, 1046)]),
            "perk": cat(*[T(f, f, 0.07, 0.2, "square", 0.25) for f in (523, 659, 784, 659, 784, 1046)]),
            "boss": cat(T(220, 220, 0.12, 0.3), T(0.1, 0.1, 0.05, 0), T(220, 220, 0.12, 0.3),
                        T(0.1, 0.1, 0.05, 0), T(165, 165, 0.35, 0.3)),
            "zap": T(1200, 2400, 0.12, 0.2, "square", 0.12),
            "grab": self._mix(T(160, 60, 0.3, 0.4), T(1500, 300, 0.3, 0.3, "noise")),
            "fight": cat(T(392, 392, 0.1, 0.25), T(523, 523, 0.25, 0.25)),
            "denied": T(150, 120, 0.12, 0.2, "square"),
        }
        for k, v in defs.items():
            self.sounds[k] = self._to_sound(v)

    def _render_track(self, name):
        spec = TRACKS[name]
        sr = self.sr
        step = int(sr * 60 / spec["bpm"] / 2)       # eighth notes
        lead = parse(spec["lead"])
        bass = parse(spec["bass"])
        drums = spec["drums"].split()
        steps = len(lead)
        n = step * steps
        out = [0.0] * n

        def voice(seq, vol, wave, duty, gate):
            ph = 0.0
            cur = None
            for si in range(steps):
                tok = seq[si % len(seq)]
                if tok == "-":
                    held = True
                else:
                    held = False
                    cur = tok
                if cur is None:
                    continue
                inc = midi(cur) / sr
                base = si * step
                length = step if held or (si + 1 < steps and seq[(si + 1) % len(seq)] == "-") \
                    else int(step * gate)
                for i in range(length):
                    ph += inc
                    if ph >= 1.0:
                        ph -= 1.0
                    if wave == "square":
                        v = vol if ph < duty else -vol
                    else:
                        v = (4 * abs(ph - 0.5) - 1) * vol
                    out[base + i] += v

        voice(lead, 0.10, "square", 0.25, 0.8)
        voice(bass, 0.20, "tri", 0.5, 0.9)
        rnd = random.Random(3)
        for si in range(steps):
            d = drums[si % len(drums)]
            if d == ".":
                continue
            base = si * step
            ln = {"k": int(step * 0.5), "s": int(step * 0.4), "h": int(step * 0.12)}[d]
            hold = 0.0
            for i in range(ln):
                t = i / ln
                if d == "k":
                    f = 150 - 110 * t
                    v = (1.0 if (i * f / sr) % 1.0 < 0.5 else -1.0) * 0.16 * (1 - t)
                else:
                    if i % (2 if d == "h" else 4) == 0:
                        hold = rnd.random() * 2 - 1
                    v = hold * (0.06 if d == "h" else 0.11) * (1 - t)
                out[base + i] += v
        return self._to_sound(out)

    # ----------------------------------------------------------- playback
    def prepare_music(self):
        if not self.ok:
            return
        for name in TRACKS:
            if name not in self.music:
                self.music[name] = self._render_track(name)

    def play(self, name, vol=1.0):
        if not self.ok:
            return
        snd = self.sounds.get(name)
        if snd is not None:
            ch = snd.play()
            if ch is not None:
                ch.set_volume(vol)

    def play_music(self, name):
        if not self.ok or self.current == name:
            return
        if name not in self.music:
            self.music[name] = self._render_track(name)
        self.current = name
        self.music_chan.stop()
        self.music_chan.set_volume(self.music_volume)
        self.music_chan.play(self.music[name], loops=-1)

    def stop_music(self):
        if self.ok:
            self.music_chan.stop()
        self.current = None
