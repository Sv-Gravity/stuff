"""Fighters, the player, enemy AI, projectiles and effects."""

import math
import random

import pygame

from . import sprites
from .sprites import ANCHOR_X, ANCHOR_Y
from .font import draw_text
from .data import ARCH_STATS, BOSS_MOVES, BOSS_PROJ, ENEMIES, PERKS


class Move:
    """One attack: frame data + hitbox + behaviour kind."""

    def __init__(self, name, wind, act, startup, active, recovery, dmg, reach=13,
                 width=14, depth=9, kb=1.2, stun=14, knockdown=False, sound="punch",
                 hitstop=3, kind="melee", group="punch", **extra):
        self.name = name
        self.wind, self.act = wind, act
        self.startup, self.active, self.recovery = startup, active, recovery
        self.dmg = dmg
        self.reach, self.width, self.depth = reach, width, depth
        self.kb, self.stun, self.knockdown = kb, stun, knockdown
        self.sound, self.hitstop = sound, hitstop
        self.kind, self.group = kind, group
        self.extra = extra
        self.total = startup + active + recovery

    def get(self, k, default=None):
        return self.extra.get(k, default)


# ----------------------------------------------------------------- player moves
PLAYER_MOVES = {
    "jab": Move("jab", "jab", "jab", 3, 3, 7, 4, reach=13, stun=12, kb=0.8),
    "cross": Move("cross", "cross", "cross", 3, 3, 8, 5, reach=14, stun=13, kb=1.0),
    "upper": Move("upper", "cross", "upper", 5, 4, 14, 9, reach=12, width=16, kb=3.2,
                  knockdown=True, sound="heavy", hitstop=6),
    "kick": Move("kick", "kick_chamber", "kick", 6, 4, 12, 8, reach=18, width=16, kb=2.2,
                 stun=18, sound="kick", hitstop=4, group="kick"),
    "kick2": Move("kick2", "kick_chamber", "kick", 5, 5, 16, 10, reach=18, width=18, kb=3.5,
                  knockdown=True, sound="heavy", hitstop=6, group="kick"),
    "hadouken": Move("hadouken", "fireball_prep", "fireball", 10, 1, 20, 12, kind="proj",
                     sound="hadouken", group="special"),
}
# (current move, button) -> next move in the chain
CHAIN = {("jab", "p"): "cross", ("cross", "p"): "upper",
         ("jab", "k"): "kick", ("cross", "k"): "kick", ("upper", "k"): "kick2",
         ("kick", "k"): "kick2", ("kick", "p"): "jab"}

# ----------------------------------------------------------------- enemy moves
# mult = damage multiplier, rng = (min, max) horizontal distance to use it
ENEMY_MOVES = {
    "jab": dict(wind="idle0", act="jab", startup=10, active=4, recovery=18, mult=1.0,
                reach=13, width=14, kb=1.2, stun=14, sound="punch", rng=(0, 20)),
    "kick": dict(wind="kick_chamber", act="kick", startup=14, active=5, recovery=22, mult=1.3,
                 reach=18, width=16, kb=2.0, stun=16, sound="kick", rng=(0, 26)),
    "long": dict(wind="idle0", act="jab", startup=16, active=8, recovery=22, mult=1.2,
                 reach=34, width=36, kb=2.0, stun=16, sound="kick", rng=(0, 52), stretch=True),
    "proj": dict(kind="proj", wind="fireball_prep", act="fireball", startup=20, active=1,
                 recovery=30, mult=1.3, rng=(34, 400), align=10, speed=2.3, sound="fireball"),
    "spread": dict(kind="spread", wind="fireball_prep", act="fireball", startup=20, active=1,
                   recovery=34, mult=1.2, rng=(34, 400), align=40, speed=2.4, sound="fireball"),
    "star": dict(kind="proj", wind="jab", act="cross", startup=14, active=1, recovery=24,
                 mult=0.8, rng=(30, 400), align=10, speed=3.0, ptype="star",
                 pcolor=(200, 200, 220), sound="swing"),
    "dash": dict(kind="charge", wind="idle1", act="dash", startup=18, active=30, recovery=22,
                 mult=1.2, rng=(24, 150), align=8, speed=3.2, reach=4, width=22, kb=2.5,
                 sound="swing"),
    "charge": dict(kind="charge", wind="idle1", act="dash", startup=22, active=45, recovery=26,
                   mult=1.6, rng=(30, 400), align=12, speed=3.8, reach=4, width=24, kb=3.5,
                   knockdown=True, sound="heavy", aura=(255, 255, 255)),
    "roll": dict(kind="charge", wind="kick_chamber", act="kick_chamber", startup=20, active=45,
                 recovery=26, mult=1.5, rng=(30, 400), align=12, speed=4.0, reach=2, width=24,
                 kb=3.5, knockdown=True, sound="heavy", aura=(120, 255, 120), spin=True),
    "psycho": dict(kind="charge", wind="arms_out", act="dash", startup=24, active=50,
                   recovery=28, mult=1.8, rng=(30, 400), align=14, speed=4.2, reach=4, width=26,
                   kb=4.0, knockdown=True, sound="heavy", aura=(190, 80, 255)),
    "grab": dict(wind="idle0", act="fireball", startup=8, active=3, recovery=26, mult=2.5,
                 reach=11, width=14, kb=3.0, knockdown=True, sound="grab", hitstop=10,
                 rng=(0, 16)),
    "upper": dict(kind="upper", wind="cross", act="upper", startup=8, active=10, recovery=26,
                  mult=1.8, reach=10, width=20, depth=11, kb=3.0, knockdown=True,
                  sound="heavy", hitstop=6, rng=(0, 22)),
    "teleport": dict(kind="teleport", wind="idle0", act="idle0", startup=26, active=1,
                     recovery=0, mult=0, rng=(0, 400), align=400),
    "slaps": dict(kind="aura", wind="jab", act="jab", startup=10, active=48, recovery=20,
                  mult=0.45, reach=14, width=20, depth=10, kb=0.6, stun=10, interval=8,
                  rng=(0, 24), alt=("jab", "cross"), sound="punch"),
    "legs": dict(kind="aura", wind="kick_chamber", act="kick", startup=10, active=48,
                 recovery=20, mult=0.45, reach=16, width=20, depth=10, kb=0.6, stun=10,
                 interval=8, rng=(0, 28), alt=("kick", "kick_chamber"), sound="kick"),
    "electric": dict(kind="aura", wind="arms_out", act="arms_out", startup=14, active=60,
                     recovery=24, mult=0.6, reach=0, width=44, depth=14, kb=2.0, stun=14,
                     interval=10, rng=(0, 34), align=14, aura=(255, 240, 80), sound="zap"),
    "lariat": dict(kind="aura", wind="arms_out", act="arms_out", startup=12, active=60,
                   recovery=24, mult=0.7, reach=0, width=42, depth=12, kb=2.5, stun=14,
                   interval=10, rng=(0, 70), align=24, travel=0.9, spin=True, sound="swing"),
    "tatsu": dict(kind="aura", wind="kick_chamber", act="kick", startup=10, active=40,
                  recovery=22, mult=0.7, reach=0, width=32, depth=10, kb=2.5, stun=14,
                  interval=10, rng=(0, 80), align=8, travel=2.0, spin=True, sound="swing"),
    "bird": dict(kind="aura", wind="kick_chamber", act="kick", startup=12, active=44,
                 recovery=22, mult=0.7, reach=0, width=34, depth=10, kb=2.5, stun=14,
                 interval=10, rng=(0, 90), align=8, travel=2.2, spin=True, sound="swing"),
}


def make_enemy_move(name, base_dmg, proj=None):
    d = dict(ENEMY_MOVES[name])
    mult = d.pop("mult")
    rng = d.pop("rng")
    wind, act = d.pop("wind"), d.pop("act")
    startup, active, recovery = d.pop("startup"), d.pop("active"), d.pop("recovery")
    if proj and d.get("kind") in ("proj", "spread") and "ptype" not in d:
        d["ptype"], d["pcolor"] = proj[0], proj[1]
    m = Move(name, wind, act, startup, active, recovery, max(1, int(round(base_dmg * mult))), **d)
    m.rng = rng
    m.align = d.get("align", 6)
    return m


# ----------------------------------------------------------------- base fighter

class Fighter:
    is_boss = False

    def __init__(self, x, y, look, key, team, hp, speed):
        self.x, self.y = float(x), float(y)
        self.z = 0.0
        self.vz = 0.0
        self.kvx = self.kvy = 0.0
        self.facing = 1
        self.look = look
        self.sprites = sprites.fighter_sprites(key, look)
        build = look.get("build", "normal")
        self.radius = {"huge": 9, "big": 8}.get(build, 6)
        self.half_w = self.radius + 1
        self.team = team
        self.hp = self.max_hp = hp
        self.speed = speed
        self.state = "idle"
        self.timer = 0
        self.move = None
        self.mt = 0
        self.hit_set = set()
        self.invuln = 0
        self.flash = 0
        self.anim_t = random.randrange(60)
        self.dead = False
        self.remove = False
        self.visible = True
        self.combo_hits = 0
        self.combo_timer = 0
        self.dash_v = (0.0, 0.0)
        self.armor = 0
        self.name = key.upper()

    # ------------------------------------------------ geometry
    @property
    def sort_y(self):
        return self.y

    def foot_rect(self):
        return pygame.Rect(int(self.x - self.radius), int(self.y - 3), self.radius * 2, 4)

    def move_by(self, dx, dy, scene):
        blocked = False
        solids = scene.solids
        r = self.radius
        if dx:
            self.x += dx
            fr = self.foot_rect()
            for s in solids:
                if fr.colliderect(s):
                    self.x = (s.left - r - 0.01) if dx > 0 else (s.right + r + 0.01)
                    blocked = True
                    fr = self.foot_rect()
        if dy:
            self.y += dy
            fr = self.foot_rect()
            for s in solids:
                if fr.colliderect(s):
                    self.y = (s.top - 1.01) if dy > 0 else (s.bottom + 3.01)
                    blocked = True
                    fr = self.foot_rect()
        l, t, rr, b = scene.bounds
        if self.x < l + r:
            self.x, blocked = l + r, True
        elif self.x > rr - r:
            self.x, blocked = rr - r, True
        if self.y < t:
            self.y, blocked = t, True
        elif self.y > b:
            self.y, blocked = b, True
        return blocked

    # ------------------------------------------------ attacks
    def start_move(self, move, scene):
        self.state = "attack"
        self.move = move
        self.mt = 0
        self.hit_set = set()
        if move.kind == "melee" or move.kind == "aura":
            scene.sfx("swing", 0.5)

    def hitbox(self):
        m = self.move
        return self.x + self.facing * m.reach * (1.15 if self.radius > 7 else 1.0), m.width / 2, m.depth

    def update_move(self, scene):
        m = self.move
        self.mt += 1
        t = self.mt
        if t == m.startup:
            self.on_active_start(scene)
        if m.startup <= t < m.startup + m.active:
            self.on_active(scene)
        if t >= m.total:
            self.state = "idle"
            self.move = None
            self.visible = True
            self.after_move(scene)

    def on_active_start(self, scene):
        m = self.move
        if m.kind in ("proj", "spread"):
            self.fire(scene)
        elif m.kind == "charge":
            p = scene.player
            dx, dy = p.x - self.x, p.y - self.y
            d = math.hypot(dx, dy) or 1
            sp = m.get("speed", 3.0)
            self.dash_v = (dx / d * sp, dy / d * sp * 0.6)
            self.facing = 1 if dx >= 0 else -1
            scene.sfx(m.sound)
        elif m.kind == "upper":
            self.vz = 4.2
            scene.sfx("swing")
        elif m.kind == "teleport":
            self.teleport(scene)

    def on_active(self, scene):
        m = self.move
        if m.kind == "charge":
            if self.move_by(self.dash_v[0], self.dash_v[1], scene):
                self.mt = m.startup + m.active      # hit a wall: stop
            self.check_hits(scene)
        elif m.kind == "aura":
            interval = m.get("interval", 10)
            if (self.mt - m.startup) % interval == 0:
                self.hit_set = set()
                if m.get("sound"):
                    scene.sfx(m.sound, 0.6)
            travel = m.get("travel")
            if travel:
                p = scene.player
                if m.name in ("tatsu", "bird"):
                    self.move_by(self.facing * travel, 0, scene)
                else:
                    dx, dy = p.x - self.x, p.y - self.y
                    d = math.hypot(dx, dy) or 1
                    self.move_by(dx / d * travel, dy / d * travel, scene)
            self.check_hits(scene)
        elif m.kind in ("melee", "upper"):
            self.check_hits(scene)

    def after_move(self, scene):
        pass

    def fire(self, scene):
        pass

    def teleport(self, scene):
        pass

    def damage_for(self, move):
        return move.dmg

    def check_hits(self, scene):
        m = self.move
        if m.kind == "aura" and m.reach == 0:
            cx, hw, depth = self.x, m.width / 2, m.depth
        else:
            cx, hw, depth = self.hitbox()
        for tgt in scene.targets_for(self.team):
            if id(tgt) in self.hit_set:
                continue
            if abs(tgt.y - self.y) > depth + getattr(tgt, "depth_pad", 0) or \
                    abs(tgt.x - cx) > hw + tgt.half_w:
                continue
            if self.z > 14 and m.kind != "upper":
                continue
            self.hit_set.add(id(tgt))
            direction = 1 if tgt.x >= self.x else -1
            if m.kind == "aura" and m.reach == 0:
                direction = 1 if tgt.x >= self.x else -1
            if scene.apply_hit(self, tgt, self.damage_for(m), direction, m):
                self.on_landed(scene, tgt)

    def on_landed(self, scene, tgt):
        pass

    # ------------------------------------------------ getting hit
    def take_hit(self, dmg, direction, move, scene, launch=None):
        if self.dead or self.invuln > 0 or self.state in ("down", "getup") or not self.visible:
            return False
        if self.state == "attack" and self.move and self.move.kind == "upper" \
                and self.mt < self.move.startup + self.move.active:
            return False   # invincible rising uppercut
        self.hp -= dmg
        self.flash = 6
        self.combo_hits += 1
        self.combo_timer = 70
        kb = move.kb if move else 2.0
        knockdown = move.knockdown if move else False
        armored = self.armor > 0 or (self.state == "attack" and self.move and
                                     self.move.kind in ("charge", "aura") and self.is_boss)
        if self.hp <= 0:
            self.hp = 0
            self.die(direction, scene)
            return True
        if armored:
            self.kvx += direction * kb * 0.2
            return True
        stun_limit = 4 if self.is_boss else 6
        if self.combo_hits >= stun_limit:
            knockdown = True
            kb = max(kb, 3.0)
        if knockdown:
            self.state = "down"
            self.timer = 40 if not self.is_boss else 26
            self.vz = 2.6 if launch is None else launch
            self.kvx = direction * kb
            self.move = None
            self.combo_hits = 0
        else:
            self.state = "hurt"
            self.timer = (move.stun if move else 14) // (2 if self.is_boss else 1)
            self.kvx = direction * kb
            self.move = None
        self.visible = True
        return True

    def die(self, direction, scene):
        self.dead = True
        self.state = "dead"
        self.timer = 70
        self.vz = 3.5
        self.kvx = direction * 2.6
        self.move = None
        self.visible = True

    # ------------------------------------------------ per-frame
    def physics(self, scene):
        self.anim_t += 1
        if self.flash:
            self.flash -= 1
        if self.invuln:
            self.invuln -= 1
        if self.armor:
            self.armor -= 1
        if self.combo_timer:
            self.combo_timer -= 1
            if self.combo_timer == 0:
                self.combo_hits = 0
        if abs(self.kvx) > 0.05 or abs(self.kvy) > 0.05:
            self.move_by(self.kvx, self.kvy, scene)
            f = 0.86 if self.z <= 0 else 0.97
            self.kvx *= f
            self.kvy *= f
        else:
            self.kvx = self.kvy = 0.0
        if self.z > 0 or self.vz:
            self.z += self.vz
            self.vz -= 0.32
            if self.z <= 0:
                self.z = 0.0
                if self.state in ("down", "dead") and self.vz < -2.5:
                    self.vz = -self.vz * 0.35   # small bounce
                    scene.dust(self.x, self.y)
                else:
                    self.vz = 0.0
        if self.state == "hurt":
            self.timer -= 1
            if self.timer <= 0:
                self.state = "idle"
        elif self.state == "down":
            self.timer -= 1
            if self.timer <= 0 and self.z <= 0:
                self.state = "getup"
                self.timer = 14
        elif self.state == "getup":
            self.timer -= 1
            if self.timer <= 0:
                self.state = "idle"
                self.invuln = max(self.invuln, 20)
        elif self.state == "dead":
            if self.z <= 0:
                self.timer -= 1
            if self.timer <= 0:
                self.remove = True
        elif self.state == "attack":
            self.update_move(scene)

    def pose(self):
        st = self.state
        if st == "dead":
            return "hurt" if self.z > 4 else "down"
        if st == "down":
            return "hurt" if self.z > 4 else "down"
        if st == "hurt":
            return "hurt"
        if st == "getup":
            return "idle1"
        if st == "attack" and self.move:
            m = self.move
            if self.mt < m.startup:
                return m.wind
            alt = m.get("alt")
            if alt and self.mt < m.startup + m.active:
                return alt[(self.mt // 3) % 2]
            if self.mt < m.startup + m.active + m.recovery // 2:
                return m.act
            return "idle0"
        if st == "walk":
            return "walk%d" % ((self.anim_t // 7) % 4)
        return "idle%d" % ((self.anim_t // 26) % 2)

    def draw_facing(self):
        m = self.move
        if self.state == "attack" and m and m.get("spin") and m.startup <= self.mt < m.startup + m.active:
            return 1 if (self.mt // 4) % 2 else -1
        return self.facing

    def draw(self, surf, ox=0, oy=0):
        if not self.visible:
            return
        sh = sprites.shadow(self.radius * 2 + 4)
        surf.blit(sh, (int(self.x) - sh.get_width() // 2 + ox, int(self.y) - sh.get_height() // 2 + oy))
        if self.invuln and self.team == "player" and (self.invuln // 3) % 2 and not self.dead:
            return
        if self.state == "dead" and self.timer < 30 and (self.timer // 3) % 2:
            return
        img = self.sprites.get(self.pose(), self.draw_facing(), flash=self.flash > 3)
        px = int(self.x) - ANCHOR_X + ox
        py = int(self.y - self.z) - ANCHOR_Y + oy
        m = self.move
        active = self.state == "attack" and m and m.startup <= self.mt < m.startup + m.active
        if active and m.get("stretch"):
            hand_y = py + ANCHOR_Y - 21
            x0 = int(self.x) + self.facing * 10 + ox
            x1 = int(self.x + self.facing * (m.reach + m.width / 2 - 2)) + ox
            pygame.draw.line(surf, sprites.OUTLINE, (x0, hand_y), (x1, hand_y), 5)
            pygame.draw.line(surf, self.look["skin"], (x0, hand_y), (x1, hand_y), 3)
            pygame.draw.circle(surf, self.look.get("gloves", self.look["skin"]), (x1, hand_y), 3)
        surf.blit(img, (px, py))
        if self.state == "attack" and m and m.get("aura") and self.mt >= m.startup - 6 \
                and self.mt < m.startup + m.active:
            col = m.get("aura")
            cx, cy = int(self.x) + ox, int(self.y - self.z) - 13 + oy
            r = 14 + (self.anim_t % 4)
            pygame.draw.ellipse(surf, col, (cx - r, cy - r, r * 2, r * 2), 1)
            for k in range(4):
                a = (self.anim_t * 0.4 + k * 1.57)
                surf.fill(col, (cx + int(math.cos(a) * r), cy + int(math.sin(a) * r), 2, 2))


# ----------------------------------------------------------------- player

class Player(Fighter):
    def __init__(self, x, y, char, run):
        super().__init__(x, y, char["look"], char["key"], "player", char["hp"], char["speed"])
        self.char = char
        self.run = run
        self.ki = 50.0
        self.max_ki = 100.0
        self.buffer = None
        self.dirs = []
        self.denied_t = 0
        self.refresh_stats(heal=False)
        self.hp = min(run.hp if run.hp is not None else self.max_hp, self.max_hp)
        self.name = char["name"]

    def perk(self, k):
        return self.run.perks.count(k)

    def refresh_stats(self, heal=False):
        c = self.char
        self.max_hp = c["hp"] + 25 * self.perk("body")
        self.speed = c["speed"] * (1.15 ** self.perk("feet"))
        self.ki_regen = 0.12 * (1.6 ** self.perk("regen"))
        self.ki_cost = 25 * (0.7 ** self.perk("focus"))
        if heal:
            self.hp = min(self.max_hp, self.hp + 25)

    def damage_for(self, move):
        p = self.char["power"]
        if move.group == "punch":
            return max(1, round(move.dmg * p * (1.25 ** self.perk("fist"))))
        if move.group == "kick":
            return max(1, round(move.dmg * p * (1.25 ** self.perk("legs"))))
        return move.dmg

    def hitbox(self):
        cx, hw, depth = super().hitbox()
        if self.move.group == "kick" and self.perk("legs"):
            cx += self.facing * 3 * min(2, self.perk("legs"))
        return cx, hw, depth

    def on_landed(self, scene, tgt):
        self.ki = min(self.max_ki, self.ki + (6 if self.perk("combo") else 3))

    def _record_dirs(self, inp):
        down = inp.held("down")
        fwd = inp.held("right") if self.facing > 0 else inp.held("left")
        self.dirs.append((down, fwd))
        if len(self.dirs) > 20:
            self.dirs.pop(0)

    def _qcf(self):
        stage = 0
        for down, fwd in self.dirs:
            if stage == 0 and down and not fwd:
                stage = 1
            elif stage == 1 and down and fwd:
                stage = 2
            elif stage == 2 and fwd and not down:
                return True
        return False

    def try_special(self, scene):
        if not self.char["complete"]:
            if self.denied_t <= 0:
                scene.float_text("SPECIALS COMING SOON", self.x, self.y - 40, (255, 220, 120))
                scene.sfx("denied")
                self.denied_t = 60
            return False
        if self.ki < self.ki_cost:
            if self.denied_t <= 0:
                scene.float_text("NOT ENOUGH KI", self.x, self.y - 40, (120, 190, 255))
                scene.sfx("denied")
                self.denied_t = 40
            return False
        self.ki -= self.ki_cost
        self.start_move(PLAYER_MOVES["hadouken"], scene)
        self.dirs.clear()
        return True

    def fire(self, scene):
        big = 1.0 + 0.25 * min(2, self.perk("shinku"))
        dmg = round(12 * (1.5 ** self.perk("shinku")) * self.char["power"])
        pierce = bool(self.perk("pierce"))
        x = self.x + self.facing * 14
        offsets = (-7, 7) if self.perk("twin") else (0,)
        for oy in offsets:
            scene.add_projectile(Projectile(x, self.y + oy, self.facing * 3.4, 0, "player", dmg,
                                            "orb", (80, 150, 255), big, pierce=pierce, kb=2.8,
                                            knockdown=True))
        scene.sfx("hadouken")
        scene.float_text("HADOUKEN!", self.x, self.y - 42, (150, 200, 255), life=36)

    def control(self, inp, scene):
        self._record_dirs(inp)
        if self.denied_t > 0:
            self.denied_t -= 1
        if self.state in ("idle", "walk"):
            self.ki = min(self.max_ki, self.ki + self.ki_regen)
            mx = (1 if inp.held("right") else 0) - (1 if inp.held("left") else 0)
            my = (1 if inp.held("down") else 0) - (1 if inp.held("up") else 0)
            if inp.pressed("special"):
                if self.try_special(scene):
                    return
            if inp.pressed("punch"):
                if self.char["complete"] and self._qcf() and self.ki >= self.ki_cost:
                    self.try_special(scene)
                else:
                    self.start_move(PLAYER_MOVES["jab"], scene)
                return
            if inp.pressed("kick"):
                self.start_move(PLAYER_MOVES["kick"], scene)
                return
            if mx or my:
                if mx:
                    self.facing = mx
                sp = self.speed * (0.7071 if mx and my else 1.0)
                self.move_by(mx * sp, my * sp * 0.85, scene)
                self.state = "walk"
            else:
                self.state = "idle"
        elif self.state == "attack":
            if inp.pressed("punch"):
                self.buffer = "p"
            elif inp.pressed("kick"):
                self.buffer = "k"
            elif inp.pressed("special"):
                self.buffer = "s"
            m = self.move
            if self.buffer and m.kind == "melee" and self.mt >= m.startup + m.active:
                if self.buffer == "s":
                    self.buffer = None
                    self.move = None
                    self.state = "idle"
                    if not self.try_special(scene):
                        self.state = "idle"
                    return
                nxt = CHAIN.get((m.name, self.buffer))
                if nxt:
                    self.buffer = None
                    self.start_move(PLAYER_MOVES[nxt], scene)

    def after_move(self, scene):
        if self.buffer:
            b = self.buffer
            self.buffer = None
            if b == "p":
                self.start_move(PLAYER_MOVES["jab"], scene)
            elif b == "k":
                self.start_move(PLAYER_MOVES["kick"], scene)
            elif b == "s":
                self.try_special(scene)

    def take_hit(self, dmg, direction, move, scene, launch=None):
        dmg = max(1, round(dmg * (0.85 ** self.perk("skin"))))
        ok = super().take_hit(dmg, direction, move, scene, launch)
        if ok and not self.dead:
            self.invuln = 50
            self.buffer = None
        return ok

    def die(self, direction, scene):
        super().die(direction, scene)
        self.timer = 10 ** 6   # stays on the floor; the scene handles game over


# ----------------------------------------------------------------- enemies

class Enemy(Fighter):
    def __init__(self, x, y, name, floor_index, rng):
        spec = ENEMIES[name]
        hp, dmg, speed, pref, moves = ARCH_STATS[spec["arch"]]
        f = floor_index
        super().__init__(x, y, spec["look"], "enemy:" + name, "enemy",
                         int(hp * (1 + 0.16 * f)), speed * (1 + 0.02 * f))
        self.name = name
        self.game = spec["game"]
        self.arch = spec["arch"]
        self.pref = pref
        base = dmg * (1 + 0.08 * f)
        self.moves = [make_enemy_move(m, base, spec.get("proj")) for m in moves]
        self.weights = [1] * len(self.moves)
        self.cool = rng.randint(40, 90)
        self.cool_range = (max(24, 70 - f * 3), max(50, 120 - f * 4))
        self.rng = rng
        self.engaged = True
        self.orbit = rng.uniform(-30, 30)
        self.think = 0
        self.tx = self.ty = None
        self.spawn_t = 24
        self.invuln = 24
        self.followup = None

    def ai(self, scene):
        if self.spawn_t > 0:
            self.spawn_t -= 1
            return
        if self.state not in ("idle", "walk"):
            return
        p = scene.player
        if p.dead:
            self.state = "idle"
            return
        dx, dy = p.x - self.x, p.y - self.y
        self.facing = 1 if dx >= 0 else -1
        if self.cool > 0:
            self.cool -= 1
        adx = abs(dx)
        if self.cool == 0 and self.engaged:
            choices = [(m, w) for m, w in zip(self.moves, self.weights)
                       if m.rng[0] <= adx <= m.rng[1] and abs(dy) <= m.align]
            if choices:
                total = sum(w for _, w in choices)
                r = self.rng.uniform(0, total)
                for m, w in choices:
                    r -= w
                    if r <= 0:
                        break
                self.start_move(m, scene)
                self.cool = self.rng.randint(*self.cool_range)
                return
        # positioning
        pref = self.preferred_distance()
        side = -1 if dx > 0 else 1
        if not self.engaged:
            pref = max(pref, 60)
        tx = p.x + side * pref
        ty = p.y + (0 if (self.engaged and self.cool < 30) else self.orbit)
        l, t, r, b = scene.bounds
        if tx < l + 14 or tx > r - 14:     # pinned against a wall: go to the other side
            tx = p.x - side * pref
        mx, my = tx - self.x, ty - self.y
        d = math.hypot(mx, my)
        if d > 3:
            sp = self.speed
            self.move_by(mx / d * sp, my / d * sp * 0.8, scene)
            self.state = "walk"
        else:
            self.state = "idle"

    def preferred_distance(self):
        return self.pref

    def fire(self, scene):
        m = self.move
        p = scene.player
        kind = m.get("ptype", "orb")
        color = m.get("pcolor", (255, 120, 80))
        sp = m.get("speed", 2.3)
        x = self.x + self.facing * 14
        if m.kind == "spread":
            for vy in (-0.55, 0.0, 0.55):
                scene.add_projectile(Projectile(x, self.y, self.facing * sp, vy, "enemy", m.dmg,
                                                kind, color, 1.0, kb=2.5))
        else:
            dy = p.y - self.y
            vy = max(-0.5, min(0.5, dy / max(20.0, abs(p.x - self.x)) * sp))
            size = 0.7 if kind == "star" else 1.0
            scene.add_projectile(Projectile(x, self.y, self.facing * sp, vy, "enemy", m.dmg,
                                            kind, color, size, kb=2.5))
        if m.sound:
            scene.sfx(m.sound, 0.7)

    def teleport(self, scene):
        p = scene.player
        scene.puff(self.x, self.y)
        side = -p.facing
        nx = p.x + side * 26
        l, t, r, b = scene.bounds
        if nx < l + 12 or nx > r - 12:
            nx = p.x - side * 26
        self.x = max(l + 12, min(r - 12, nx))
        self.y = p.y
        self.move_by(0.01, 0.01, scene)
        self.facing = 1 if p.x >= self.x else -1
        self.visible = True
        scene.puff(self.x, self.y)
        self.followup = next((m for m in self.moves if m.name in ("kick", "jab")), None)

    def update_move(self, scene):
        m = self.move
        if m.kind == "teleport" and self.mt == 6:
            self.visible = False
            scene.puff(self.x, self.y)
        super().update_move(scene)

    def after_move(self, scene):
        if self.followup:
            m = self.followup
            self.followup = None
            self.start_move(m, scene)

    def die(self, direction, scene):
        super().die(direction, scene)
        scene.on_enemy_killed(self)


class Boss(Enemy):
    is_boss = True

    def __init__(self, x, y, char, floor_index, rng, shadow=False):
        Fighter.__init__(self, x, y, char["look"], "boss:" + char["key"] + (":s" if shadow else ""),
                         "enemy", 160 + 30 * floor_index, char["speed"] * 0.75)
        if shadow:
            look = dict(char["look"])
            look["top"] = look["bottom"] = (70, 66, 84)
            look["headband"] = (120, 40, 160)
            look["skin"] = sprites.shade(look["skin"], 0.75)
            self.look = look
            self.sprites = sprites.fighter_sprites("boss:" + char["key"] + ":s", look)
        self.key = char["key"]
        self.name = ("SHADOW " if shadow else "") + char["name"]
        self.game = "SF2"
        self.arch = "boss"
        self.pref = 18
        base = 7 + 0.6 * floor_index
        proj = BOSS_PROJ.get(char["key"])
        self.moves, self.weights = [], []
        for name, w in BOSS_MOVES[char["key"]]:
            mv = make_enemy_move(name, base, proj)
            if proj and name == "proj":
                mv.extra["speed"] = 2.6
            self.moves.append(mv)
            self.weights.append(w)
        self.has_proj = any(m.kind in ("proj", "spread") for m in self.moves)
        self.cool = 60
        self.cool_range = (max(16, 46 - floor_index * 2), max(36, 80 - floor_index * 3))
        self.rng = rng
        self.engaged = True
        self.orbit = 0
        self.think = 0
        self.spawn_t = 0
        self.invuln = 0
        self.followup = None
        self.mode = "press"
        self.mode_t = 180
        self.proj_name = proj[2] if proj else None
        self.frozen = True     # until the round call finishes

    def preferred_distance(self):
        self.mode_t -= 1
        if self.mode_t <= 0:
            self.mode = "zone" if (self.has_proj and self.mode == "press" and
                                   self.rng.random() < 0.6) else "press"
            self.mode_t = self.rng.randint(120, 240)
        return 95 if self.mode == "zone" else 18

    def ai(self, scene):
        if self.frozen:
            return
        super().ai(scene)

    def start_move(self, move, scene):
        super().start_move(move, scene)
        if move.kind in ("proj", "spread") and self.proj_name:
            scene.float_text(self.proj_name + "!", self.x, self.y - 46, (255, 230, 150), life=40)

    def die(self, direction, scene):
        Fighter.die(self, direction, scene)
        self.timer = 10 ** 6
        scene.on_boss_killed(self)


# ----------------------------------------------------------------- projectiles

class Projectile:
    def __init__(self, x, y, vx, vy, team, dmg, kind, color, size=1.0, pierce=False,
                 kb=2.5, knockdown=False, life=220):
        self.x, self.y = float(x), float(y)
        self.vx, self.vy = vx, vy
        self.team = team
        self.dmg = dmg
        self.kind = kind
        self.color = color
        self.size = size
        self.pierce = pierce
        self.life = life
        self.dead = False
        self.t = 0
        self.hit_set = set()
        self.move = Move("proj", "", "", 0, 0, 0, dmg, kb=kb, stun=16, knockdown=knockdown,
                         sound="kick", hitstop=4, kind="proj")
        self.frames, self.flipped = sprites.projectile_frames(kind, color, size)
        self.radius = 7 * size

    @property
    def sort_y(self):
        return self.y

    def update(self, scene):
        self.t += 1
        self.x += self.vx
        self.y += self.vy
        self.life -= 1
        l, t, r, b = scene.bounds
        if self.life <= 0 or self.x < l - 4 or self.x > r + 4 or self.y < t - 6 or self.y > b + 4:
            self.dead = True
            scene.spark(self.x, self.y - 14, self.color)
            return
        pt = (int(self.x), int(self.y) - 1)
        for o in scene.proj_blockers:
            if o.collidepoint(pt):
                self.dead = True
                scene.spark(self.x, self.y - 14, self.color)
                return
        for tgt in scene.targets_for(self.team):
            if id(tgt) in self.hit_set:
                continue
            if abs(tgt.y - self.y) <= 8 + getattr(tgt, "depth_pad", 0) and \
                    abs(tgt.x - self.x) <= self.radius + tgt.half_w:
                if tgt is not None and getattr(tgt, "z", 0) > 18:
                    continue
                self.hit_set.add(id(tgt))
                direction = 1 if self.vx >= 0 else -1
                if scene.apply_hit(self, tgt, self.dmg, direction, self.move):
                    if not self.pierce:
                        self.dead = True
                        return

    def draw(self, surf, ox=0, oy=0):
        frames = self.frames if self.vx >= 0 else self.flipped
        img = frames[(self.t // 4) % len(frames)]
        sh = sprites.shadow(10)
        surf.blit(sh, (int(self.x) - 5 + ox, int(self.y) - 2 + oy))
        surf.blit(img, (int(self.x) - img.get_width() // 2 + ox,
                        int(self.y) - 15 - img.get_height() // 2 + oy))


# ----------------------------------------------------------------- effects

class Effect:
    def __init__(self, frames, x, y, rate=3, sort_y=None):
        self.frames = frames
        self.x, self.y = x, y
        self.rate = rate
        self.t = 0
        self.dead = False
        self._sort = sort_y if sort_y is not None else y + 30

    @property
    def sort_y(self):
        return self._sort

    def update(self, scene=None):
        self.t += 1
        if self.t >= len(self.frames) * self.rate:
            self.dead = True

    def draw(self, surf, ox=0, oy=0):
        img = self.frames[min(len(self.frames) - 1, self.t // self.rate)]
        surf.blit(img, (int(self.x) - img.get_width() // 2 + ox, int(self.y) - img.get_height() // 2 + oy))


class Debris:
    def __init__(self, x, y, color, rng):
        self.x, self.y = x, y
        self.vx = rng.uniform(-2.5, 2.5)
        self.vy = rng.uniform(-4, -1.5)
        self.color = color
        self.size = rng.choice((2, 2, 3))
        self.t = 0
        self.floor = y + rng.uniform(10, 30)
        self.dead = False

    @property
    def sort_y(self):
        return self.floor

    def update(self, scene=None):
        self.t += 1
        self.x += self.vx
        self.y += self.vy
        self.vy += 0.25
        if self.y >= self.floor:
            self.y = self.floor
            self.vx *= 0.6
            self.vy = -self.vy * 0.3 if abs(self.vy) > 1 else 0
        if self.t > 80:
            self.dead = True

    def draw(self, surf, ox=0, oy=0):
        surf.fill(self.color, (int(self.x) + ox, int(self.y) + oy, self.size, self.size))


class FloatText:
    def __init__(self, text, x, y, color, life=50, scale=1):
        self.text, self.x, self.y = text, x, y
        self.color = color
        self.life = life
        self.scale = scale
        self.dead = False

    @property
    def sort_y(self):
        return 10 ** 6

    def update(self, scene=None):
        self.life -= 1
        self.y -= 0.35
        if self.life <= 0:
            self.dead = True

    def draw(self, surf, ox=0, oy=0):
        draw_text(surf, self.text, self.x + ox, self.y + oy, self.color, self.scale, align="center")


class Pickup:
    def __init__(self, kind, x, y):
        self.kind = kind
        self.x, self.y = float(x), float(y)
        self.t = random.randrange(60)
        self.img = sprites.item_sprite(kind)
        self.dead = False

    @property
    def sort_y(self):
        return self.y

    def update(self, scene=None):
        self.t += 1

    def draw(self, surf, ox=0, oy=0):
        bob = int(math.sin(self.t * 0.12) * 2)
        sh = sprites.shadow(10)
        surf.blit(sh, (int(self.x) - 5 + ox, int(self.y) - 2 + oy))
        surf.blit(self.img, (int(self.x) - 7 + ox, int(self.y) - 16 + bob + oy))


def perk_label(k):
    return PERKS[k][0]
