"""Window setup and the fixed 60fps main loop."""

import argparse
import os
import random

import pygame

from .config import W, H, FPS
from .audio import Audio
from .input import Input
from .font import draw_text


class Game:
    def __init__(self, screen, audio, seed=None, show_fps=False):
        self.screen = screen
        self.canvas = pygame.Surface((W, H))
        self.audio = audio
        self.inp = Input()
        self.seed = seed
        self.show_fps = show_fps
        self.clock = pygame.time.Clock()
        self.running = True
        from .scenes import TitleScene
        self.scene = TitleScene(self)
        self._next = None

    def change(self, scene):
        self._next = scene

    def step(self):
        """One fixed 1/60s tick of game logic."""
        self.scene.update(self.inp)
        if self._next is not None:
            self.scene = self._next
            self._next = None

    def render(self):
        self.scene.draw(self.canvas)
        if self.show_fps:
            draw_text(self.canvas, "%d FPS" % round(self.clock.get_fps()), W - 2, H - 9,
                      (120, 255, 120), align="right")
        if self.screen is not self.canvas:
            self.screen.blit(self.canvas, (0, 0))
        pygame.display.flip()

    def run(self):
        while self.running:
            self.inp.new_frame()
            for ev in pygame.event.get():
                if ev.type == pygame.QUIT:
                    self.running = False
                elif ev.type == pygame.KEYDOWN and ev.key == pygame.K_F11:
                    try:
                        pygame.display.toggle_fullscreen()
                    except pygame.error:
                        pass
                elif ev.type == pygame.KEYDOWN and ev.key == pygame.K_F3:
                    self.show_fps = not self.show_fps
                else:
                    self.inp.handle(ev)
            self.inp.update_held()
            self.step()
            self.render()
            self.clock.tick(FPS)


def open_window(fullscreen=False, vsync=True):
    flags = pygame.SCALED | (pygame.FULLSCREEN if fullscreen else 0)
    attempts = []
    if vsync:
        attempts.append((flags, 1))
    attempts += [(flags, 0), (0, 0)]
    for fl, vs in attempts:
        try:
            if vs:
                return pygame.display.set_mode((W, H), fl, vsync=1)
            return pygame.display.set_mode((W, H), fl)
        except (pygame.error, TypeError):
            continue
    raise SystemExit("Could not open a window")


def main(argv=None):
    ap = argparse.ArgumentParser(description="World Warrior Dungeon - a Street Fighter II roguelike")
    ap.add_argument("--fullscreen", "-f", action="store_true", help="start in fullscreen")
    ap.add_argument("--no-vsync", action="store_true", help="disable vsync")
    ap.add_argument("--mute", action="store_true", help="no sound")
    ap.add_argument("--fps", action="store_true", help="show the frame rate (also F3)")
    ap.add_argument("--seed", type=int, default=None, help="fixed dungeon seed")
    args = ap.parse_args(argv)

    os.environ.setdefault("SDL_RENDER_SCALE_QUALITY", "0")   # crisp nearest-neighbour scaling
    pygame.mixer.pre_init(22050, -16, 1, 512)
    pygame.init()
    pygame.display.set_caption("World Warrior Dungeon")
    screen = open_window(args.fullscreen, not args.no_vsync)
    pygame.mouse.set_visible(False)
    screen.fill((0, 0, 0))
    draw_text(screen, "LOADING...", W // 2, H // 2 - 4, (255, 220, 60), align="center")
    pygame.display.flip()

    audio = Audio(enabled=not args.mute)
    audio.prepare_music()
    game = Game(screen, audio, args.seed, args.fps)
    game.run()
    pygame.quit()
