"""Procedural 8-bit pixel art.

Every fighter is drawn from a "look" (palette + build + hair style) and a set
of skeletal poses, so no image files are needed. Frames are rendered once and
cached, which keeps per-frame drawing to plain blits.
"""

import math
import random

import pygame

OUTLINE = (16, 12, 24)
CANVAS_W, CANVAS_H = 48, 48
ANCHOR_X, ANCHOR_Y = 24, 45      # where the feet touch the ground

# Pose skeletons for a fighter facing right, in pixels at "normal" build.
# Origin is the feet on the ground; negative y is up.
# hip, neck, head, front/back knee+foot, front/back elbow+hand.
_BASE = dict(hip=(0, -12), neck=(1, -22), head=(2, -26),
             fk=(5, -6), ff=(5, 0), bk=(-4, -6), bf=(-5, 0),
             fe=(6, -17), fh=(9, -20), be=(3, -16), bh=(6, -18))


def _pose(**kw):
    p = dict(_BASE)
    p.update(kw)
    return p


POSES = {
    "idle0": _pose(),
    "idle1": _pose(hip=(0, -11), neck=(1, -21), head=(2, -25),
                   fe=(6, -16), fh=(9, -19), be=(3, -15), bh=(6, -17)),
    "walk0": _pose(ff=(7, 0), fk=(5, -6), bf=(-6, 0), bk=(-3, -6)),
    "walk1": _pose(hip=(0, -12.5), ff=(2, 0), fk=(3, -7), bf=(-1, -1), bk=(0, -6)),
    "walk2": _pose(ff=(-4, 0), fk=(-1, -6), bf=(6, 0), bk=(4, -6)),
    "walk3": _pose(hip=(0, -12.5), ff=(1, -1), fk=(2, -6), bf=(-2, 0), bk=(-1, -7)),
    "jab": _pose(neck=(2, -22), head=(3, -26), fe=(8, -21), fh=(14, -21),
                 be=(2, -16), bh=(5, -18)),
    "cross": _pose(neck=(3, -22), head=(4, -26), fe=(5, -17), fh=(7, -19),
                   be=(7, -21), bh=(14, -20), bf=(-6, 0), bk=(-3, -5)),
    "upper": _pose(neck=(2, -23), head=(3, -27), fk=(3, -6), ff=(4, 0),
                   fe=(7, -25), fh=(8, -32), be=(1, -16), bh=(4, -18)),
    "kick_chamber": _pose(fk=(6, -13), ff=(4, -7), bk=(-2, -6), bf=(-3, 0),
                          neck=(0, -22), head=(1, -26)),
    "kick": _pose(fk=(7, -14), ff=(16, -16), bk=(-1, -6), bf=(-2, 0),
                  neck=(-2, -21), head=(-3, -25), fe=(1, -17), fh=(4, -20),
                  be=(-5, -18), bh=(-8, -15)),
    "hurt": _pose(hip=(-1, -12), neck=(-3, -21), head=(-5, -24),
                  fe=(2, -24), fh=(4, -28), be=(-6, -20), bh=(-9, -23)),
    "down": dict(hip=(-2, -3), neck=(8, -4), head=(12, -5),
                 fk=(-8, -4), ff=(-13, -2), bk=(-7, -2), bf=(-12, -1),
                 fe=(4, -2), fh=(0, -1), be=(10, -2), bh=(14, -1)),
    "fireball_prep": _pose(hip=(0, -11), neck=(0, -21), head=(1, -25),
                           ff=(8, 0), fk=(6, -6), bf=(-8, 0), bk=(-5, -6),
                           fe=(-1, -15), fh=(-4, -14), be=(-2, -14), bh=(-5, -13)),
    "fireball": _pose(hip=(0, -11), neck=(3, -21), head=(4, -25),
                      ff=(8, 0), fk=(6, -6), bf=(-8, 0), bk=(-5, -6),
                      fe=(7, -18), fh=(12, -18), be=(6, -17), bh=(11, -17)),
    "arms_out": _pose(fe=(5, -21), fh=(10, -21), be=(-4, -21), bh=(-9, -21)),
    "dash": _pose(neck=(5, -21), head=(7, -24), ff=(6, 0), fk=(5, -6),
                  bf=(-8, -1), bk=(-4, -6), fe=(10, -20), fh=(15, -20),
                  be=(1, -17), bh=(-3, -15)),
    "victory": _pose(fe=(5, -26), fh=(6, -33), be=(-2, -16), bh=(-4, -12)),
}
POSE_NAMES = list(POSES.keys())

# sx, sy, limb width, shoulder width, hip width, head radius
BUILDS = {
    "normal": (1.0, 1.0, 3, 9, 7, 3.5),
    "slim": (0.9, 1.0, 3, 7, 6, 3.4),
    "big": (1.2, 1.1, 4, 12, 9, 4.0),
    "huge": (1.4, 1.2, 5, 15, 11, 4.5),
    "lanky": (0.9, 1.18, 3, 8, 6, 3.5),
    "small": (0.9, 0.9, 3, 8, 6, 3.4),
}


def shade(c, k):
    return (max(0, min(255, int(c[0] * k))),
            max(0, min(255, int(c[1] * k))),
            max(0, min(255, int(c[2] * k))))


def _outline(surf, color=OUTLINE):
    mask = pygame.mask.from_surface(surf)
    sil = mask.to_surface(setcolor=color + (255,), unsetcolor=(0, 0, 0, 0))
    out = pygame.Surface(surf.get_size(), pygame.SRCALPHA)
    for ox, oy in ((-1, 0), (1, 0), (0, -1), (0, 1)):
        out.blit(sil, (ox, oy))
    out.blit(surf, (0, 0))
    return out


def render_pose(look, pose_name):
    P = POSES[pose_name]
    sx, sy, lw, shw, hipw, hr = BUILDS[look.get("build", "normal")]
    surf = pygame.Surface((CANVAS_W, CANVAS_H), pygame.SRCALPHA)

    def pt(key, extra=(0, 0)):
        x, y = P[key]
        return (ANCHOR_X + (x + extra[0]) * sx, ANCHOR_Y + (y + extra[1]) * sy)

    def ip(p):
        return (int(round(p[0])), int(round(p[1])))

    skin = look["skin"]
    top = look["top"]
    bottom = look["bottom"]
    legs = look.get("legs", bottom)
    arm_col = top if look.get("sleeves") else skin
    hand = look.get("gloves", skin)
    feet = look.get("boots", skin)
    hair = look.get("hair", (40, 30, 20))
    style = look.get("style", "short")
    lying = pose_name == "down"

    def limb(a, b, c, upper, lower, end, end_r):
        A, B, C = ip(a), ip(b), ip(c)
        pygame.draw.line(surf, upper, A, B, lw)
        pygame.draw.line(surf, lower, B, C, lw)
        pygame.draw.circle(surf, lower, B, max(1, lw // 2))
        pygame.draw.circle(surf, end, C, end_r)

    hip = pt("hip")
    neck = pt("neck")
    off_f = (1.5, 0) if not lying else (0, 0.8)
    off_b = (-1.5, 0) if not lying else (0, -0.8)
    fshoulder = pt("neck", (1, 1.5) if not lying else (-1, 0))
    bshoulder = pt("neck", (-1.5, 1.5) if not lying else (-1, -1))
    end_r = max(1, lw // 2 + 1)

    # back leg and back arm (darker so the figure reads as 3D)
    limb(pt("hip", off_b), pt("bk"), pt("bf"), shade(legs, 0.75), shade(legs, 0.75),
         shade(feet, 0.75), end_r)
    limb(bshoulder, pt("be"), pt("bh"), shade(arm_col, 0.75), shade(skin, 0.75),
         shade(hand, 0.75), end_r)

    # torso as a quad between hips and shoulders
    dx, dy = neck[0] - hip[0], neck[1] - hip[1]
    ln = math.hypot(dx, dy) or 1.0
    nx, ny = -dy / ln, dx / ln
    quad = [
        (hip[0] + nx * hipw / 2, hip[1] + ny * hipw / 2),
        (neck[0] + nx * shw / 2, neck[1] + ny * shw / 2),
        (neck[0] - nx * shw / 2, neck[1] - ny * shw / 2),
        (hip[0] - nx * hipw / 2, hip[1] - ny * hipw / 2),
    ]
    pygame.draw.polygon(surf, top, [ip(q) for q in quad])
    if look.get("gi"):
        mid = (hip[0] + dx * 0.45, hip[1] + dy * 0.45)
        pygame.draw.line(surf, shade(top, 0.7), ip(neck), ip(mid), 1)
    if look.get("trunks"):
        tr = look["trunks"]
        pygame.draw.circle(surf, tr, ip(hip), int(hipw / 2 + 1))
    belt = look.get("belt")
    if belt:
        b1 = (hip[0] + dx * 0.18 + nx * hipw / 2, hip[1] + dy * 0.18 + ny * hipw / 2)
        b2 = (hip[0] + dx * 0.18 - nx * hipw / 2, hip[1] + dy * 0.18 - ny * hipw / 2)
        pygame.draw.line(surf, belt, ip(b1), ip(b2), 2)
    if look.get("cape"):
        cp = look["cape"]
        pygame.draw.line(surf, cp, ip(bshoulder), ip((hip[0] - 4 * sx, hip[1] + 4 * sy)), 3)

    # front leg
    limb(pt("hip", off_f), pt("fk"), pt("ff"), legs, legs, feet, end_r)

    # head + hair
    hx, hy = pt("head")
    r = hr
    fwd = 1 if not lying else 0
    if style == "wild":
        pygame.draw.ellipse(surf, hair, (hx - r - 3, hy - r - 3, 2 * r + 5, 2 * r + 6))
    if style in ("short", "spiky", "long", "buns", "topknot", "ponytail", "mohawk_full"):
        pygame.draw.ellipse(surf, hair, (hx - r - 1.5, hy - r - 1, 2 * r + 1, 2 * r + 1))
    if style == "long":
        surf.fill(hair, (int(hx - r - 1), int(hy - 1), 3, int(7 * sy)))
    if style == "ponytail":
        pygame.draw.line(surf, hair, ip((hx - r, hy)), ip((hx - r - 3, hy + 10 * sy)), 2)
    pygame.draw.ellipse(surf, skin, (hx - r + fwd * 0.5, hy - r, 2 * r, 2 * r + 1))
    if style in ("short", "spiky", "long", "buns", "topknot", "ponytail"):
        surf.fill(hair, (int(hx - r), int(hy - r - 1), int(2 * r), 2))
        surf.fill(hair, (int(hx - r), int(hy - r), 2, int(r)))
    if style == "spiky":
        for i in range(3):
            bx = hx - r + i * 2.5
            pygame.draw.polygon(surf, hair, [ip((bx, hy - r)), ip((bx - 2, hy - r - 3)),
                                             ip((bx + 2, hy - r))])
    if style == "buns":
        pygame.draw.circle(surf, hair, ip((hx - r + 0.5, hy - r + 0.5)), 2)
        pygame.draw.circle(surf, hair, ip((hx + r - 1, hy - r + 0.5)), 2)
        surf.fill((240, 240, 240), (int(hx - r - 1), int(hy - r - 1), 2, 1))
    if style == "topknot":
        pygame.draw.circle(surf, hair, ip((hx - 1, hy - r - 2)), 2)
    if style == "mohawk":
        surf.fill(hair, (int(hx - 2), int(hy - r - 3), 4, 4))
    if style == "flattop":
        surf.fill(hair, (int(hx - r), int(hy - r - 5), int(2 * r + 1), 6))
    if style == "cap":
        cap = look.get("cap", (170, 30, 40))
        surf.fill(cap, (int(hx - r - 1), int(hy - r - 3), int(2 * r + 2), 4))
        surf.fill(shade(cap, 0.6), (int(hx), int(hy - r + 1), int(r + 2), 1))
        surf.fill((240, 200, 60), (int(hx), int(hy - r - 2), 2, 2))
    if style == "hood":
        hood = look.get("hood", hair)
        pygame.draw.ellipse(surf, hood, (hx - r - 0.5, hy - r - 1, 2 * r + 1.5, 2 * r + 2.5))
        surf.fill(skin, (int(hx), int(hy - 1), int(r), 2))
    if look.get("beard"):
        surf.fill(hair, (int(hx - 1), int(hy + 1), int(r + 1), 3))
    if look.get("mask"):
        surf.fill((235, 235, 240), (int(hx - 1), int(hy - r + 1), int(r + 2), int(r + 1)))
    band = look.get("headband")
    if band:
        surf.fill(band, (int(hx - r), int(hy - r + 1), int(2 * r), 1))
        if not lying:
            pygame.draw.line(surf, band, ip((hx - r, hy - r + 1)), ip((hx - r - 4, hy - r + 3)), 1)
    # eye
    if not look.get("mask") and style != "hood":
        surf.fill((20, 20, 30), (int(hx + r * 0.45), int(hy - 0.5), 1, 1))
    else:
        surf.fill((200, 30, 30) if look.get("mask") else (20, 20, 30),
                  (int(hx + r * 0.45), int(hy - 0.5), 1, 1))
    if look.get("eyepatch"):
        surf.fill((20, 20, 30), (int(hx + r * 0.3), int(hy - 1), 2, 2))

    # front arm last so punches read clearly
    limb(fshoulder, pt("fe"), pt("fh"), arm_col, skin, hand, end_r)
    if look.get("claw") and not lying:
        h = ip(pt("fh"))
        for k in (-1, 0, 1):
            pygame.draw.line(surf, (220, 220, 235), (h[0] + 1, h[1] + k), (h[0] + 6, h[1] + k * 2), 1)

    return _outline(surf)


class FighterSprites:
    """All frames for one look, both facings, plus white hit-flash versions."""

    def __init__(self, look):
        self.right = {}
        self.left = {}
        self.flash_r = {}
        self.flash_l = {}
        for name in POSE_NAMES:
            img = render_pose(look, name)
            self.right[name] = img
            self.left[name] = pygame.transform.flip(img, True, False)
        self.build = look.get("build", "normal")

    def get(self, pose, facing, flash=False):
        if flash:
            cache = self.flash_r if facing > 0 else self.flash_l
            img = cache.get(pose)
            if img is None:
                base = self.get(pose, facing)
                img = pygame.mask.from_surface(base).to_surface(
                    setcolor=(255, 255, 255, 255), unsetcolor=(0, 0, 0, 0))
                cache[pose] = img
            return img
        return (self.right if facing > 0 else self.left)[pose]


_fighter_cache = {}


def fighter_sprites(key, look):
    fs = _fighter_cache.get(key)
    if fs is None:
        fs = FighterSprites(look)
        _fighter_cache[key] = fs
    return fs


def portrait(fs, size=32):
    """Head-and-shoulders crop of the idle frame, scaled up."""
    sx, sy = BUILDS[fs.build][0], BUILDS[fs.build][1]
    img = fs.right["idle0"]
    cx = int(ANCHOR_X + 2 * sx)
    cy = int(ANCHOR_Y - 24 * sy)
    rect = pygame.Rect(cx - 8, cy - 7, 16, 16).clip(img.get_rect())
    crop = img.subsurface(rect).copy()
    return pygame.transform.scale(crop, (size, size))


_shadow_cache = {}


def shadow(w):
    s = _shadow_cache.get(w)
    if s is None:
        s = pygame.Surface((w, max(3, w // 3)), pygame.SRCALPHA)
        pygame.draw.ellipse(s, (0, 0, 0, 90), s.get_rect())
        _shadow_cache[w] = s
    return s


# --------------------------------------------------------------- projectiles

_proj_cache = {}


def projectile_frames(kind, color, size=1.0):
    key = (kind, color, size)
    if key in _proj_cache:
        return _proj_cache[key]
    frames = []
    core = (255, 255, 255)
    glow = color
    dark = shade(color, 0.55)
    for f in range(4):
        w, h = int(22 * size), int(16 * size)
        s = pygame.Surface((w, h), pygame.SRCALPHA)
        cx, cy = w // 2 + int(2 * size), h // 2
        if kind == "orb":
            r = int(6 * size) + (f % 2)
            for i in range(4):  # trailing wisps
                tx = cx - r - 2 - i * 2
                ty = cy + ((i + f) % 3 - 1) * 2
                s.fill(dark, (tx, ty, 2, 2))
            pygame.draw.circle(s, dark, (cx, cy), r + 1)
            pygame.draw.circle(s, glow, (cx, cy), r)
            pygame.draw.circle(s, shade(glow, 1.3), (cx, cy), max(1, r - 2))
            pygame.draw.circle(s, core, (cx + 1, cy - 1), max(1, r - 4))
        elif kind == "crescent":
            r = int(7 * size)
            pygame.draw.circle(s, glow, (cx, cy), r)
            pygame.draw.circle(s, (0, 0, 0, 0), (cx - 4, cy), r)
            pygame.draw.circle(s, core, (cx + r - 2, cy), 1)
            if f % 2:
                s.fill(core, (cx + 2, cy - r + 2, 1, 2 * r - 4))
        elif kind == "flame":
            r = int(5 * size) + (f % 2)
            pts = [(cx + r + 2, cy), (cx - r - 6, cy - r), (cx - r - 3, cy), (cx - r - 6, cy + r)]
            pygame.draw.polygon(s, (230, 60, 20), pts)
            pygame.draw.circle(s, (255, 150, 30), (cx, cy), r)
            pygame.draw.circle(s, (255, 240, 120), (cx + 1, cy), max(1, r - 2))
        elif kind == "star":
            ang = f * math.pi / 8
            for k in range(4):
                a = ang + k * math.pi / 2
                ex = cx + math.cos(a) * 5 * size
                ey = cy + math.sin(a) * 5 * size
                pygame.draw.line(s, glow, (cx, cy), (int(ex), int(ey)), 2)
            s.fill(core, (cx - 1, cy - 1, 2, 2))
        frames.append(_outline(s, shade(color, 0.3)) if kind != "orb" else s)
    flipped = [pygame.transform.flip(fr, True, False) for fr in frames]
    _proj_cache[key] = (frames, flipped)
    return frames, flipped


# --------------------------------------------------------------- effects

def spark_frames(color=(255, 240, 150)):
    frames = []
    for f in range(5):
        s = pygame.Surface((17, 17), pygame.SRCALPHA)
        r = 2 + f * 2
        c = (255, 255, 255) if f < 2 else color
        for k in range(8):
            a = k * math.pi / 4 + (0.4 if f % 2 else 0)
            ln = r if k % 2 == 0 else r * 0.6
            pygame.draw.line(s, c, (8, 8), (int(8 + math.cos(a) * ln), int(8 + math.sin(a) * ln)), 1)
        if f < 3:
            pygame.draw.circle(s, (255, 255, 255), (8, 8), 3 - f)
        frames.append(s)
    return frames


def puff_frames(color=(220, 220, 220)):
    frames = []
    for f in range(6):
        s = pygame.Surface((20, 14), pygame.SRCALPHA)
        r = 3 + f
        a = max(0, 220 - f * 35)
        col = color + (a,)
        pygame.draw.circle(s, col, (6, 9), r // 1)
        pygame.draw.circle(s, col, (13, 8), max(1, r - 1))
        frames.append(s)
    return frames


# --------------------------------------------------------------- items

_item_cache = {}


def item_sprite(kind):
    if kind in _item_cache:
        return _item_cache[kind]
    _item_cache[kind] = img = _item_sprite(kind)
    return img


def _item_sprite(kind):
    s = pygame.Surface((14, 14), pygame.SRCALPHA)
    if kind == "chicken":
        pygame.draw.ellipse(s, (170, 90, 40), (1, 3, 9, 8))
        pygame.draw.ellipse(s, (210, 130, 60), (2, 4, 6, 4))
        pygame.draw.line(s, (245, 240, 225), (8, 8), (12, 11), 2)
        s.fill((245, 240, 225), (11, 10, 3, 3))
    elif kind == "ki":
        pygame.draw.circle(s, (40, 80, 200), (7, 7), 5)
        pygame.draw.circle(s, (120, 190, 255), (7, 7), 4)
        pygame.draw.circle(s, (255, 255, 255), (6, 6), 2)
    elif kind == "coin":
        pygame.draw.ellipse(s, (170, 120, 20), (3, 2, 8, 10))
        pygame.draw.ellipse(s, (250, 210, 50), (4, 3, 6, 8))
        s.fill((255, 250, 180), (6, 5, 1, 4))
    elif kind == "scroll":
        s.fill((230, 210, 160), (2, 3, 10, 8))
        s.fill((150, 100, 50), (1, 2, 2, 10))
        s.fill((150, 100, 50), (11, 2, 2, 10))
        pygame.draw.circle(s, (200, 30, 30), (7, 7), 2)
    return _outline(s)


_barrel_cache = {}


def barrel_sprite(color=(150, 95, 50)):
    if color in _barrel_cache:
        return _barrel_cache[color]
    s = pygame.Surface((16, 20), pygame.SRCALPHA)
    pygame.draw.ellipse(s, color, (1, 1, 14, 18))
    s.fill(color, (1, 4, 14, 12))
    s.fill(shade(color, 1.25), (4, 3, 3, 14))
    for y in (5, 13):
        s.fill((90, 90, 100), (1, y, 14, 2))
    pygame.draw.ellipse(s, shade(color, 0.7), (2, 0, 12, 5))
    _barrel_cache[color] = img = _outline(s)
    return img


# --------------------------------------------------------------- the car

def car_sprite(stage):
    """Side view of the bonus-stage car. stage 0 = pristine ... 4 = scrap."""
    w, h = 112, 52
    s = pygame.Surface((w, h), pygame.SRCALPHA)
    rnd = random.Random(7)
    red = (200, 30, 35)
    dark_red = (130, 15, 20)
    glass = (150, 210, 240)
    tire = (30, 30, 34)
    squash = [0, 0, 2, 5, 11][stage]
    body_top = 24 + squash // 2
    # cabin
    if stage < 4:
        cab = [(30, body_top), (40, 10 + squash), (78, 10 + squash), (90, body_top)]
        pygame.draw.polygon(s, red, cab)
        win1 = [(36, body_top - 1), (43, 13 + squash), (57, 13 + squash), (57, body_top - 1)]
        win2 = [(61, body_top - 1), (61, 13 + squash), (76, 13 + squash), (85, body_top - 1)]
        for win in (win1, win2):
            if stage >= 2:
                pygame.draw.polygon(s, (30, 30, 40), win)
                pygame.draw.line(s, glass, win[0], win[2], 1)
            else:
                pygame.draw.polygon(s, glass, win)
                if stage == 1:
                    pygame.draw.line(s, (255, 255, 255), win[1], win[3], 1)
    # body
    s.fill(red, (6, body_top, 100, 16 - squash // 3))
    s.fill(dark_red, (6, body_top + 12 - squash // 3, 100, 3))
    s.fill((230, 230, 235), (4, body_top + 10 - squash // 3, 5, 4))     # bumpers
    if stage < 2:
        s.fill((230, 230, 235), (103, body_top + 10, 5, 4))
    s.fill((255, 230, 120), (101, body_top + 3, 4, 3))                   # headlight
    s.fill((255, 60, 60), (6, body_top + 3, 3, 3))
    if stage < 3:
        pygame.draw.line(s, dark_red, (58, body_top + 1), (58, body_top + 11), 1)
    else:
        s.fill((25, 20, 25), (44, body_top + 1, 28, 10))                 # door ripped off
    # dents
    for _ in range(stage * 6):
        dx = rnd.randint(8, 100)
        dy = rnd.randint(body_top, body_top + 9)
        s.fill(dark_red, (dx, dy, rnd.randint(2, 5), 2))
    # wheels
    wy = body_top + 16 - squash // 3
    for wx in (24, 86):
        if stage >= 3 and wx == 86:
            s.fill(tire, (wx - 7, wy, 14, 4))
            continue
        pygame.draw.circle(s, tire, (wx, wy), 7)
        pygame.draw.circle(s, (170, 170, 180), (wx, wy), 3)
    if stage == 4:
        pygame.draw.line(s, (25, 20, 25), (54, body_top), (60, body_top + 14), 3)
    return _outline(s)
