"""High score storage in the user's home folder."""

import json
import os

PATH = os.path.join(os.path.expanduser("~"), ".world_warrior_dungeon.json")


def load():
    try:
        with open(PATH) as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def store(data):
    try:
        with open(PATH, "w") as f:
            json.dump(data, f)
    except OSError:
        pass
