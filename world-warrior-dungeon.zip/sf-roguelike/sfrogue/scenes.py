"""All game screens: title, select, stage intro, dungeon, car bonus, perks, endings."""

import math
import random

import pygame

from .config import (W, H, HUD_H, PLAY_L, PLAY_R, PLAY_T, PLAY_B, MID_X, MID_Y, DOOR_W,
                     DOOR_H, GRID, WHITE, YELLOW, RED, DARK)
from .font import draw_text, wrap, text_width
from . import sprites
from .sprites import shade
from .data import (CHARACTERS, CHAR_BY_KEY, STAGES, WORLD_WARRIORS, GRAND_MASTERS, PERKS,
                   ENEMIES, BONUS_AFTER_FLOOR)
from .entities import (Player, Enemy, Boss, Projectile, Effect, Debris, FloatText, Pickup)
from .world import Floor, Breakable, door_rect, draw_door_bars, OPPOSITE, DIRS
from . import save


# ======================================================================= run state

class Run:
    """Everything that persists across floors in one attempt."""

    def __init__(self, char, seed=None):
        self.seed = seed if seed is not None else random.randrange(1 << 30)
        self.rng = random.Random(self.seed)
        self.char = char
        warriors = WORLD_WARRIORS[:]
        self.rng.shuffle(warriors)
        self.order = warriors + GRAND_MASTERS
        self.floor = 0
        self.perks = []
        self.hp = None
        self.ki = 50.0
        self.score = 0
        self.kills = 0
        self.frames = 0
        self.bonus_done = False

    @property
    def stage_key(self):
        return self.order[self.floor]

    @property
    def stage(self):
        return STAGES[self.stage_key]

    def offer_perks(self, n=3):
        pool = [k for k, (_, _, stack) in PERKS.items() if stack or k not in self.perks]
        if not self.char["complete"]:
            pool = [k for k in pool if k not in ("focus", "shinku", "pierce", "twin")]
        self.rng.shuffle(pool)
        return pool[:n]


# ======================================================================= base scene

class Scene:
    music = None

    def __init__(self, game):
        self.game = game
        self.t = 0
        if self.music:
            game.audio.play_music(self.music)

    def sfx(self, name, vol=1.0):
        self.game.audio.play(name, vol)

    def update(self, inp):
        self.t += 1

    def draw(self, surf):
        pass


def blink(t, period=40):
    return (t // (period // 2)) % 2 == 0


_big_cache = {}


def big_sprite(fs, pose, facing, scale=2):
    key = (id(fs), pose, facing, scale)
    img = _big_cache.get(key)
    if img is None:
        base = fs.get(pose, facing)
        img = pygame.transform.scale(base, (base.get_width() * scale, base.get_height() * scale))
        _big_cache[key] = img
    return img


def draw_backdrop(surf, top=(30, 20, 60), bottom=(120, 40, 50)):
    for y in range(0, H, 4):
        k = y / H
        c = tuple(int(top[i] + (bottom[i] - top[i]) * k) for i in range(3))
        surf.fill(c, (0, y, W, 4))


# ======================================================================= title

class TitleScene(Scene):
    music = "title"

    def __init__(self, game):
        super().__init__(game)
        ryu = CHAR_BY_KEY["ryu"]
        self.fs = sprites.fighter_sprites("ryu", ryu["look"])
        self.fs_ken = sprites.fighter_sprites("ken", CHAR_BY_KEY["ken"]["look"])
        self.orb_frames = sprites.projectile_frames("orb", (80, 150, 255), 1.5)[0]
        rng = random.Random(4)
        self.sky = pygame.Surface((W, H))
        draw_backdrop(self.sky, (10, 10, 40), (150, 50, 50))
        for _ in range(60):
            self.sky.fill((255, 255, 220), (rng.randrange(W), rng.randrange(90), 1, 1))
        x = 0
        while x < W:
            w = rng.randrange(14, 34)
            h = rng.randrange(20, 60)
            self.sky.fill((20, 14, 30), (x, 150 - h, w, h + 30))
            for wy in range(150 - h + 4, 148, 6):
                for wx in range(x + 3, x + w - 3, 5):
                    if rng.random() < 0.35:
                        self.sky.fill((240, 200, 90), (wx, wy, 2, 2))
            x += w
        self.sky.fill((40, 30, 40), (0, 150, W, 30))
        self.sky.fill((70, 55, 60), (0, 150, W, 2))
        self.high = save.load().get("high", 0)

    def update(self, inp):
        super().update(inp)
        if inp.any_confirm():
            self.sfx("confirm")
            self.game.change(SelectScene(self.game))
        elif inp.pressed("back"):
            self.game.running = False

    def draw(self, s):
        s.blit(self.sky, (0, 0))
        draw_text(s, "WORLD WARRIOR", W // 2, 14, (255, 210, 60), 3, shadow=(170, 30, 30), align="center")
        draw_text(s, "DUNGEON", W // 2, 40, (255, 140, 40), 3, shadow=(170, 30, 30), align="center")
        draw_text(s, "A STREET FIGHTER II ROGUELIKE", W // 2, 66, (230, 230, 255), align="center")
        # Ryu throws a Hadouken across the screen, forever
        cyc = self.t % 150
        pose = "idle%d" % ((self.t // 26) % 2)
        if 10 <= cyc < 22:
            pose = "fireball_prep"
        elif 22 <= cyc < 46:
            pose = "fireball"
        s.blit(big_sprite(self.fs, pose, 1), (40, 152 - 90))
        s.blit(big_sprite(self.fs_ken, "hurt" if 70 <= cyc < 90 else "idle%d" % ((self.t // 26) % 2), -1),
               (W - 40 - 96, 152 - 90))
        if 22 <= cyc < 72:
            ox = 100 + (cyc - 22) * 2.4
            img = self.orb_frames[(self.t // 4) % 4]
            s.blit(img, (int(ox), 104))
        if 70 <= cyc < 76:
            s.blit(pygame.transform.scale(sprites.spark_frames()[min(4, cyc - 70)], (34, 34)),
                   (W - 110, 96))
        if blink(self.t):
            draw_text(s, "PRESS START", W // 2, 80, WHITE, 2, align="center")
        draw_text(s, "HIGH SCORE %07d" % self.high, W // 2, 158, (255, 220, 120), align="center")
        draw_text(s, "ENTER/J: START   ESC: QUIT   F11: FULLSCREEN", W // 2, 170, (180, 180, 200),
                  align="center", shadow=None)


# ======================================================================= character select

SELECT_GRID = [["balrog", "ryu", "honda", "blanka", "guile", "vega"],
               ["sagat", "ken", "chunli", "zangief", "dhalsim", "bison"]]


class SelectScene(Scene):
    music = "title"

    def __init__(self, game):
        super().__init__(game)
        self.cx, self.cy = 1, 0           # cursor starts on Ryu
        self.portraits = {}
        for c in CHARACTERS:
            fs = sprites.fighter_sprites(c["key"], c["look"])
            self.portraits[c["key"]] = sprites.portrait(fs, 30)
        self.flag_t = 0
        self.chosen = None

    @property
    def current(self):
        return CHAR_BY_KEY[SELECT_GRID[self.cy][self.cx]]

    def update(self, inp):
        super().update(inp)
        if self.chosen:
            self.flag_t += 1
            if self.flag_t > 50:
                run = Run(self.chosen, self.game.seed)
                self.game.change(StageIntroScene(self.game, run))
            return
        moved = False
        if inp.pressed("left"):
            self.cx = (self.cx - 1) % 6; moved = True
        if inp.pressed("right"):
            self.cx = (self.cx + 1) % 6; moved = True
        if inp.pressed("up") or inp.pressed("down"):
            self.cy = 1 - self.cy; moved = True
        if moved:
            self.sfx("select")
        if inp.any_confirm():
            self.chosen = self.current
            self.sfx("confirm")
        elif inp.pressed("back"):
            self.game.change(TitleScene(self.game))

    def draw(self, s):
        draw_backdrop(s, (20, 20, 70), (60, 20, 50))
        draw_text(s, "SELECT YOUR FIGHTER", W // 2, 4, YELLOW, 1, align="center")
        c = self.current
        fs = sprites.fighter_sprites(c["key"], c["look"])
        pose = "victory" if self.chosen else "idle%d" % ((self.t // 26) % 2)
        s.blit(big_sprite(fs, pose, 1), (6, 12))
        x = 108
        draw_text(s, c["name"], x, 16, WHITE, 2)
        draw_text(s, c["country"], x, 34, (255, 200, 120))
        if c["complete"]:
            draw_text(s, "READY TO FIGHT", x + 70, 34, (120, 255, 140))
        else:
            draw_text(s, "PLACEHOLDER", x + 70, 34, (255, 120, 120))
        draw_text(s, "HP", x, 46, (200, 200, 220))
        draw_text(s, "SPD", x, 55, (200, 200, 220))
        draw_text(s, "POW", x, 64, (200, 200, 220))
        for i, (val, lo, hi) in enumerate(((c["hp"], 80, 140), (c["speed"], 1.0, 1.8),
                                           (c["power"], 0.9, 1.35))):
            frac = max(0.08, min(1.0, (val - lo) / (hi - lo)))
            s.fill((40, 40, 60), (x + 22, 46 + i * 9, 80, 6))
            s.fill((255, 200, 60), (x + 22, 46 + i * 9, int(80 * frac), 6))
        draw_text(s, "MOVES:", x, 76, (200, 200, 220))
        moves = c["specials"] if c["complete"] else ["PUNCH COMBO", "KICK"] + \
            [m + " (SOON)" for m in c["specials"][:2]]
        for i, m in enumerate(moves[:4]):
            draw_text(s, "- " + m, x + 4, 85 + i * 8, WHITE, shadow=None)
        # portrait grid
        gx0, gy0 = (W - 6 * 34) // 2, 118
        for row in range(2):
            for col in range(6):
                key = SELECT_GRID[row][col]
                px, py = gx0 + col * 34, gy0 + row * 30
                s.fill((10, 10, 20), (px, py, 32, 28))
                s.blit(self.portraits[key], (px + 1, py - 1), (0, 0, 30, 28))
                if not CHAR_BY_KEY[key]["complete"]:
                    s.fill((0, 0, 0), (px + 1, py + 22, 30, 5))
                    draw_text(s, "WIP", px + 16, py + 21, (160, 160, 170), align="center", shadow=None)
                sel = (row == self.cy and col == self.cx)
                if sel and (blink(self.t, 16) or self.chosen):
                    pygame.draw.rect(s, (255, 60, 60), (px - 1, py - 1, 34, 30), 2)
                    draw_text(s, "1P", px + 1, py - 8, (255, 80, 80), shadow=None)
                else:
                    pygame.draw.rect(s, (90, 90, 120), (px - 1, py - 1, 34, 30), 1)


# ======================================================================= stage intro

class StageIntroScene(Scene):
    def __init__(self, game, run):
        super().__init__(game)
        game.audio.stop_music()
        self.run = run
        st = run.stage
        self.stage = st
        boss_char = CHAR_BY_KEY[run.stage_key]
        self.shadow = boss_char["key"] == run.char["key"]
        self.boss_name = ("SHADOW " if self.shadow else "") + boss_char["name"]
        self.pfs = sprites.fighter_sprites(run.char["key"], run.char["look"])
        self.bfs = sprites.fighter_sprites(boss_char["key"], boss_char["look"])
        self.sfx("fight")
        # build sprite sheets now, one per frame, so the dungeon never hitches
        self.warm = [("enemy:" + n, ENEMIES[n]["look"]) for n in self.stage["enemies"]]
        self.warm.append(("boss:" + boss_char["key"], boss_char["look"]))
        if run.floor + 1 == BONUS_AFTER_FLOOR:
            self.warm += [("enemy:" + n, ENEMIES[n]["look"]) for n in ("MAD GEAR THUG", "SHADALOO GRUNT")]

    def update(self, inp):
        super().update(inp)
        if self.warm:
            sprites.fighter_sprites(*self.warm.pop())
            return
        if self.t > 30 and (inp.any_confirm() or self.t > 200):
            self.game.change(DungeonScene(self.game, self.run))

    def draw(self, s):
        draw_backdrop(s, (10, 10, 30), shade(self.stage["fa"], 0.6))
        n = self.run.floor + 1
        title = "FINAL STAGE" if n == 12 else "STAGE %d / 12" % n
        draw_text(s, title, W // 2, 8, YELLOW, 2, align="center")
        draw_text(s, self.stage["name"], W // 2, 28, WHITE, 2, align="center")
        draw_text(s, self.stage["place"], W // 2, 46, (255, 200, 120), align="center")
        slide = min(1.0, self.t / 25)
        s.blit(big_sprite(self.pfs, "idle0", 1), (int(-90 + 110 * slide), 66))
        bimg = big_sprite(self.bfs, "idle0", -1)
        if self.shadow:
            bimg = bimg.copy()
            bimg.fill((90, 60, 120, 255), special_flags=pygame.BLEND_RGBA_MULT)
        s.blit(bimg, (int(W + 90 - 110 * slide - 96), 66))
        if self.t > 25:
            draw_text(s, "VS", W // 2, 100, (255, 80, 60), 3, align="center")
        draw_text(s, self.run.char["name"], 68, 160, WHITE, align="center")
        draw_text(s, self.boss_name, W - 68, 160, WHITE, align="center")
        names = self.stage["enemies"]
        draw_text(s, "SPOTTED: " + ", ".join(names[:5]), W // 2, 172, (170, 170, 200),
                  align="center", shadow=None)


# ======================================================================= combat base

class CombatScene(Scene):
    """Shared fighting logic for dungeon rooms and the car bonus stage."""

    def __init__(self, game, run):
        super().__init__(game)
        self.run = run
        self.enemies = []
        self.projectiles = []
        self.effects = []
        self.pickups = []
        self.barrels = []
        self.solids = []
        self.proj_blockers = []
        self.bounds = (PLAY_L, PLAY_T, PLAY_R, PLAY_B)
        self.hitstop = 0
        self.shake = 0
        self.slowmo = 0
        self.banners = []
        self.paused = False
        self.pause_sel = 0
        self.player_dead_t = 0
        self.spark_img = sprites.spark_frames()
        self.puff_img = sprites.puff_frames()
        self.dust_img = sprites.puff_frames((190, 170, 140))
        self.fx_rng = random.Random()
        self.extra_targets = []

    # --------------------------------------------------- helpers used by entities
    def targets_for(self, team):
        if team == "player":
            out = [e for e in self.enemies if not e.dead and e.visible and e.spawn_t <= 0]
            out.extend(b for b in self.barrels if not b.dead)
            out.extend(self.extra_targets)
            return out
        p = self.player
        return [p] if not p.dead else []

    def apply_hit(self, src, tgt, dmg, direction, move):
        if isinstance(tgt, Breakable):
            tgt.hp -= dmg
            tgt.flash = 8
            self.sfx("punch")
            self.spark(tgt.x, tgt.y - 10)
            if tgt.hp <= 0:
                self.break_barrel(tgt)
            self.hitstop = max(self.hitstop, 2)
            return True
        if hasattr(tgt, "car_hit"):
            return tgt.car_hit(self, dmg, move)
        if not tgt.take_hit(dmg, direction, move, self):
            return False
        hs = move.hitstop if move else 3
        self.hitstop = max(self.hitstop, hs)
        self.spark(tgt.x + direction * 2, tgt.y - 16 - tgt.z)
        self.sfx(move.sound if move and move.sound in ("punch", "kick", "heavy", "grab") else "punch")
        if move and (move.knockdown or move.name == "grab"):
            self.shake = max(self.shake, 8 if move.name == "grab" else 5)
        if tgt is self.player:
            self.sfx("hurt", 0.6)
            self.shake = max(self.shake, 4)
            if tgt.dead:
                self.on_player_killed()
        return True

    def break_barrel(self, b):
        b.dead = True
        self.sfx("car")
        for _ in range(10):
            self.effects.append(Debris(b.x, b.y - 10, self.fx_rng.choice(((150, 95, 50), (90, 90, 100),
                                                                            (190, 130, 70))), self.fx_rng))
        r = self.fx_rng.random()
        kind = "chicken" if r < 0.35 else "coin" if r < 0.8 else "ki"
        self.drop(kind, b.x, b.y)
        self.refresh_solids()

    def drop(self, kind, x, y):
        self.pickups.append(Pickup(kind, x, y))

    def refresh_solids(self):
        pass

    def spark(self, x, y, color=(255, 240, 150)):
        self.effects.append(Effect(self.spark_img, x, y, 2, sort_y=10 ** 5))

    def puff(self, x, y):
        self.effects.append(Effect(self.puff_img, x, y - 8, 3, sort_y=y + 1))

    def dust(self, x, y):
        self.effects.append(Effect(self.dust_img, x, y - 4, 3, sort_y=y - 1))

    def float_text(self, text, x, y, color=WHITE, life=50, scale=1):
        x = max(text_width(text, scale) // 2 + 2, min(W - text_width(text, scale) // 2 - 2, x))
        self.effects.append(FloatText(text, x, y, color, life, scale))

    def add_projectile(self, p):
        self.projectiles.append(p)

    def banner(self, text, frames=60, color=YELLOW, scale=3, y=None):
        self.banners.append([text, frames, color, scale, y if y is not None else MID_Y - 14])

    def on_enemy_killed(self, e):
        self.run.kills += 1
        self.run.score += 100 * (self.run.floor + 1)
        self.sfx("ko", 0.5)
        if self.player.perk("fury"):
            self.player.hp = min(self.player.max_hp, self.player.hp + 3 * self.player.perk("fury"))
        r = self.fx_rng.random()
        if r < 0.25:
            self.drop("coin", e.x, e.y)
        elif r < 0.36:
            self.drop("chicken", e.x, e.y)
        elif r < 0.46:
            self.drop("ki", e.x, e.y)

    def on_boss_killed(self, b):
        pass

    def on_player_killed(self):
        self.slowmo = 90
        self.player_dead_t = 1
        self.banner("K.O.", 150, (255, 60, 40), 4)
        self.sfx("ko")
        self.game.audio.stop_music()

    def collect(self, pk):
        p = self.player
        pk.dead = True
        if pk.kind == "chicken":
            amt = 30 * (2 if p.perk("chicken") else 1)
            p.hp = min(p.max_hp, p.hp + amt)
            self.float_text("+%d HP" % amt, p.x, p.y - 40, (120, 255, 140))
            self.sfx("pickup")
        elif pk.kind == "ki":
            p.ki = p.max_ki
            self.float_text("KI FULL", p.x, p.y - 40, (120, 190, 255))
            self.sfx("pickup")
        elif pk.kind == "coin":
            self.run.score += 250
            self.float_text("+250", p.x, p.y - 40, (255, 220, 80))
            self.sfx("coin")
        elif pk.kind == "scroll":
            self.grant_perk()

    def grant_perk(self):
        offer = self.run.offer_perks(1)
        if not offer:
            return
        k = offer[0]
        self.run.perks.append(k)
        self.player.refresh_stats(heal=(k == "body"))
        name, desc, _ = PERKS[k]
        self.banner(name, 120, (255, 220, 120), 2, MID_Y - 30)
        self.banner(desc, 120, WHITE, 1, MID_Y - 10)
        self.sfx("perk")

    # --------------------------------------------------- per-frame
    def update_pause(self, inp):
        if inp.pressed("up") or inp.pressed("down"):
            self.pause_sel = 1 - self.pause_sel
            self.sfx("select")
        if inp.pressed("start") or inp.pressed("punch"):
            if self.pause_sel == 0:
                self.paused = False
            else:
                self.game.change(TitleScene(self.game))
        elif inp.pressed("back"):
            self.paused = False

    def update_world(self, inp):
        """Returns False when the frame was frozen (hitstop / slow-mo)."""
        for b in self.banners:
            b[1] -= 1
        self.banners = [b for b in self.banners if b[1] > 0]
        if self.shake:
            self.shake -= 1
        if self.hitstop > 0:
            self.hitstop -= 1
            return False
        if self.slowmo > 0:
            self.slowmo -= 1
            if self.slowmo % 2:
                return False
        self.run.frames += 1
        p = self.player
        if not p.dead:
            p.control(inp, self)
        p.physics(self)
        alive = [e for e in self.enemies if not e.dead]
        if self.t % 20 == 0 and alive:
            alive.sort(key=lambda e: abs(e.x - p.x) + abs(e.y - p.y))
            k = 2 + self.run.floor // 4
            for i, e in enumerate(alive):
                e.engaged = e.is_boss or i < k
        for e in self.enemies:
            e.ai(self)
            e.physics(self)
        # keep fighters from stacking on each other
        bodies = [e for e in alive if e.state != "attack" or e.move.kind != "charge"]
        for i, a in enumerate(bodies):
            for b in bodies[i + 1:]:
                dx = b.x - a.x
                if abs(dx) < a.radius + b.radius and abs(b.y - a.y) < 6:
                    push = 0.5 if dx >= 0 else -0.5
                    a.move_by(-push, 0, self)
                    b.move_by(push, 0, self)
            if not p.dead and abs(a.x - p.x) < a.radius + p.radius - 2 and abs(a.y - p.y) < 5 \
                    and a.z <= 0 and p.z <= 0:
                a.move_by(0.6 if a.x >= p.x else -0.6, 0, self)
        self.enemies = [e for e in self.enemies if not e.remove]
        for pr in self.projectiles:
            pr.update(self)
        # fireballs cancel each other out
        mine = [q for q in self.projectiles if q.team == "player" and not q.dead]
        theirs = [q for q in self.projectiles if q.team != "player" and not q.dead]
        for a in mine:
            for b in theirs:
                if not b.dead and abs(a.x - b.x) < 10 and abs(a.y - b.y) < 9:
                    a.dead = b.dead = True
                    self.spark(a.x, a.y - 15)
                    self.sfx("kick", 0.7)
        self.projectiles = [q for q in self.projectiles if not q.dead]
        for fx in self.effects:
            fx.update(self)
        self.effects = [fx for fx in self.effects if not fx.dead]
        for pk in self.pickups:
            pk.update()
            if not p.dead and abs(pk.x - p.x) < 10 and abs(pk.y - p.y) < 8:
                self.collect(pk)
        self.pickups = [pk for pk in self.pickups if not pk.dead]
        if self.player_dead_t:
            self.player_dead_t += 1
            if self.player_dead_t > 150:
                self.game.change(GameOverScene(self.game, self.run, False))
        return True

    def drawables(self):
        items = []
        items.extend(self.pickups)
        items.extend(b for b in self.barrels if not b.dead)
        items.extend(self.enemies)
        items.append(self.player)
        items.extend(self.projectiles)
        items.extend(self.effects)
        return items

    def draw_world(self, s, bg):
        ox = oy = 0
        if self.shake:
            ox = self.fx_rng.randint(-2, 2)
            oy = self.fx_rng.randint(-1, 1)
        s.blit(bg, (ox, oy))
        self.draw_floor_layer(s, ox, oy)
        items = self.drawables()
        items.sort(key=lambda d: d.sort_y)
        for d in items:
            d.draw(s, ox, oy)
        for text, fr, col, sc, y in self.banners:
            draw_text(s, text, W // 2, y, col, sc, shadow=(80, 10, 10), align="center")

    def draw_floor_layer(self, s, ox, oy):
        pass

    def draw_pause(self, s):
        veil = pygame.Surface((W, H), pygame.SRCALPHA)
        veil.fill((0, 0, 0, 150))
        s.blit(veil, (0, 0))
        draw_text(s, "PAUSED", W // 2, 50, YELLOW, 3, align="center")
        for i, opt in enumerate(("CONTINUE", "QUIT TO TITLE")):
            col = WHITE if i == self.pause_sel else (130, 130, 150)
            draw_text(s, ("> " if i == self.pause_sel else "  ") + opt, W // 2, 92 + i * 14, col, 1,
                      align="center")
        perks = ", ".join(PERKS[k][0] for k in self.run.perks) or "NONE YET"
        for i, line in enumerate(wrap("TECHNIQUES: " + perks, 50)[:4]):
            draw_text(s, line, W // 2, 132 + i * 9, (200, 200, 220), align="center")

    # --------------------------------------------------- HUD
    def draw_hud(self, s, center1, center2, boss=None):
        s.fill((8, 6, 14), (0, 0, W, HUD_H))
        s.fill((60, 50, 80), (0, HUD_H - 1, W, 1))
        p = self.player
        draw_text(s, p.name, 4, 2, WHITE, shadow=None)
        self._bar(s, 4, 10, 96, 5, p.hp / p.max_hp, (255, 220, 40), (190, 30, 30))
        s.fill((30, 30, 50), (4, 16, 60, 3))
        s.fill((80, 160, 255), (4, 16, int(60 * p.ki / p.max_ki), 3))
        if p.char["complete"]:
            for k in range(1, int(p.max_ki // p.ki_cost) + 1):
                tx = 4 + int(60 * k * p.ki_cost / p.max_ki)
                if tx < 64:
                    s.fill((10, 10, 20), (tx, 16, 1, 3))
        draw_text(s, "%d" % p.hp, 100, 2, (255, 230, 150), shadow=None, align="right")
        draw_text(s, center1, MID_X, 2, YELLOW, shadow=None, align="center")
        draw_text(s, center2, MID_X, 11, (200, 200, 220), shadow=None, align="center")
        if boss is not None:
            draw_text(s, boss.name, W - 4, 2, WHITE, shadow=None, align="right")
            self._bar(s, W - 100, 10, 96, 5, boss.hp / boss.max_hp, (255, 220, 40), (190, 30, 30),
                      rtl=True)
            return True
        return False

    @staticmethod
    def _bar(s, x, y, w, h, frac, fg, bg, rtl=False):
        frac = max(0.0, min(1.0, frac))
        s.fill((255, 255, 255), (x - 1, y - 1, w + 2, h + 2))
        s.fill(bg, (x, y, w, h))
        fw = int(w * frac)
        if rtl:
            s.fill(fg, (x + w - fw, y, fw, h))
        else:
            s.fill(fg, (x, y, fw, h))


# ======================================================================= dungeon

class DungeonScene(CombatScene):
    def __init__(self, game, run):
        self.music = run.stage["music"]
        super().__init__(game, run)
        self.stage = run.stage
        self.floor = Floor(run.floor, run.stage_key, run.stage, run.rng.randrange(1 << 30))
        self.boss_char = CHAR_BY_KEY[run.stage_key]
        self.player = Player(MID_X, MID_Y, run.char, run)
        self.player.ki = run.ki
        self.room = None
        self.room_rng = random.Random(run.rng.randrange(1 << 30))
        self.fade = 0
        self.pending = None
        self.boss = None
        self.boss_intro = 0
        self.stairs = False
        self.clear_t = 0
        self.lock_color = (180, 180, 190)
        for r in self.floor.rooms.values():
            self.floor.background(r)
        self.enter_room(self.floor.start, None)

    # --------------------------------------------------- rooms
    def refresh_solids(self):
        r = self.room
        self.solids = r.solids()
        self.proj_blockers = [o.rect.inflate(0, 4) for o in r.obstacles] + \
                             [b.rect for b in r.barrels if not b.dead]

    def enter_room(self, pos, via):
        if self.room is not None:
            self.room.items = [pk for pk in self.pickups if not pk.dead]
        self.room = room = self.floor.rooms[pos]
        first = not room.visited
        room.visited = True
        self.enemies = []
        self.projectiles = []
        self.effects = [fx for fx in self.effects if isinstance(fx, FloatText)]
        self.pickups = list(room.items)
        self.barrels = room.barrels
        self.refresh_solids()
        p = self.player
        if via == "up":
            p.x, p.y = MID_X, PLAY_B - 3
        elif via == "down":
            p.x, p.y = MID_X, PLAY_T + 3
        elif via == "left":
            p.x, p.y = PLAY_R - 10, MID_Y
        elif via == "right":
            p.x, p.y = PLAY_L + 10, MID_Y
        p.kvx = p.kvy = 0
        p.move_by(0.01, 0.01, self)
        if room.kind == "treasure" and first:
            self.pickups.append(Pickup("scroll", MID_X, MID_Y + 2))
        if not room.cleared:
            if room.kind == "boss":
                self.start_boss()
            else:
                self.spawn_wave()
                if self.enemies:
                    self.sfx("slam")

    def spawn_wave(self):
        rng = self.room_rng
        n = min(6, rng.randint(2, 3) + self.run.floor // 3)
        pool = list(self.stage["enemies"])
        rng.shuffle(pool)
        for i in range(n):
            for _try in range(40):
                x = rng.uniform(PLAY_L + 20, PLAY_R - 20)
                y = rng.uniform(PLAY_T + 8, PLAY_B - 6)
                if math.hypot(x - self.player.x, y - self.player.y) < 90:
                    continue
                fr = pygame.Rect(int(x - 10), int(y - 4), 20, 6)
                if any(fr.colliderect(s) for s in self.solids):
                    continue
                e = Enemy(x, y, pool[i % len(pool)], self.run.floor, rng)
                self.enemies.append(e)
                self.puff(x, y)
                break

    def start_boss(self):
        shadow = self.boss_char["key"] == self.run.char["key"]
        b = Boss(MID_X, PLAY_T + 24, self.boss_char, self.run.floor, self.room_rng, shadow)
        b.facing = -1 if self.player.x < b.x else 1
        self.enemies = [b]
        self.boss = b
        self.boss_intro = 120
        self.game.audio.play_music("boss")
        self.sfx("boss")
        self.banner("VS " + b.name, 70, WHITE, 2, MID_Y - 24)
        self.player.state = "idle"

    def on_boss_killed(self, b):
        self.slowmo = 100
        self.hitstop = 20
        self.banner("K.O.", 120, (255, 60, 40), 4)
        self.sfx("ko")
        self.run.score += 2000 * (self.run.floor + 1)
        self.game.audio.stop_music()
        for e in self.enemies:
            if e is not b and not e.dead:
                e.die(1, self)

    def room_done(self):
        return all(e.dead for e in self.enemies)

    def update(self, inp):
        super().update(inp)
        if self.paused:
            self.update_pause(inp)
            return
        if (inp.pressed("start") or inp.pressed("back")) and not self.player_dead_t:
            self.paused = True
            self.pause_sel = 0
            return
        if self.fade:
            self.fade -= 1
            if self.fade == 10 and self.pending:
                pos, via = self.pending
                self.pending = None
                self.enter_room(pos, via)
            return
        if self.boss_intro > 0:
            self.boss_intro -= 1
            if self.boss_intro == 40:
                self.banner("FIGHT!", 40, (255, 80, 40), 4)
                self.sfx("fight")
            if self.boss_intro == 0 and self.boss:
                self.boss.frozen = False
            for b in self.banners:
                b[1] -= 1
            self.banners = [b for b in self.banners if b[1] > 0]
            return
        if not self.update_world(inp):
            return
        room = self.room
        if not room.cleared and self.room_done() and not self.player_dead_t:
            if room.kind == "boss" and self.slowmo > 0:
                pass
            else:
                room.cleared = True
                self.sfx("door")
                if room.kind == "boss":
                    self.stairs = True
                    self.banner("STAGE CLEAR!", 150, YELLOW, 2)
                    p = self.player
                    heal = int(p.max_hp * 0.3)
                    p.hp = min(p.max_hp, p.hp + heal)
                    self.float_text("+%d HP" % heal, p.x, p.y - 40, (120, 255, 140))
                    self.sfx("stairs")
                elif self.player.hp < self.player.max_hp * 0.5 and self.room_rng.random() < 0.4:
                    self.drop("chicken", MID_X, MID_Y)
        p = self.player
        if room.cleared and not p.dead and p.state in ("idle", "walk"):
            self.check_doors(inp)
            if self.stairs and room.kind == "boss" and abs(p.x - MID_X) < 10 and abs(p.y - MID_Y) < 7:
                self.leave_floor()

    def check_doors(self, inp):
        p = self.player
        for d in self.room.doors:
            go = False
            if d == "up" and p.y <= PLAY_T + 0.5 and abs(p.x - MID_X) < DOOR_W / 2 - 3 and inp.held("up"):
                go = True
            elif d == "down" and p.y >= PLAY_B - 0.5 and abs(p.x - MID_X) < DOOR_W / 2 - 3 and inp.held("down"):
                go = True
            elif d == "left" and p.x <= PLAY_L + p.radius + 0.5 and abs(p.y - MID_Y) < DOOR_H / 2 - 2 \
                    and inp.held("left"):
                go = True
            elif d == "right" and p.x >= PLAY_R - p.radius - 0.5 and abs(p.y - MID_Y) < DOOR_H / 2 - 2 \
                    and inp.held("right"):
                go = True
            if go:
                v = DIRS[d]
                self.pending = ((self.room.pos[0] + v[0], self.room.pos[1] + v[1]), d)
                self.fade = 20
                self.sfx("door", 0.6)
                return

    def go_to(self, pos, via="up"):
        """Instant room change (used by tests)."""
        self.enter_room(pos, via)

    def leave_floor(self):
        self.run.hp = self.player.hp
        self.run.ki = self.player.ki
        self.sfx("stairs")
        self.game.change(PerkScene(self.game, self.run))

    # --------------------------------------------------- drawing
    def draw_floor_layer(self, s, ox, oy):
        room = self.room
        if not room.cleared:
            for d in room.doors:
                draw_door_bars(s, d, self.lock_color)
        if self.stairs and room.kind == "boss":
            x, y = MID_X + ox, MID_Y + oy
            s.fill((20, 15, 25), (x - 12, y - 8, 24, 14))
            for i in range(4):
                s.fill(shade((150, 140, 130), 1 - i * 0.2), (x - 10, y - 6 + i * 3, 20, 2))
            if blink(self.t, 30):
                draw_text(s, "NEXT STAGE", x, y - 18, YELLOW, align="center")
        if room.kind == "treasure":
            s.fill((120, 115, 110), (MID_X - 9 + ox, MID_Y - 2 + oy, 18, 6))
            s.fill((160, 155, 150), (MID_X - 9 + ox, MID_Y - 3 + oy, 18, 2))
        if room.kind == "start" and self.run.floor == 0:
            lines = ["MOVE: ARROWS / WASD", "PUNCH: J   KICK: K   HADOUKEN: L",
                     "OR DOWN, DOWN-FWD, FWD + PUNCH", "CLEAR ROOMS, FIND THE BOSS"]
            for i, ln in enumerate(lines):
                draw_text(s, ln, MID_X + ox, PLAY_T + 10 + i * 9 + oy, (255, 255, 255),
                          shadow=(0, 0, 0), align="center")

    def draw_minimap(self, s):
        cw, ch, gap = 6, 3, 1
        x0 = W - 4 - GRID * (cw + gap)
        y0 = 2
        known = set()
        for pos, r in self.floor.rooms.items():
            if r.visited:
                known.add(pos)
                for v in DIRS.values():
                    nb = (pos[0] + v[0], pos[1] + v[1])
                    if nb in self.floor.rooms:
                        known.add(nb)
        for pos in known:
            r = self.floor.rooms[pos]
            col = (90, 90, 110) if r.visited else (45, 45, 60)
            if r.kind == "boss":
                col = (220, 50, 50)
            elif r.kind == "treasure":
                col = (230, 200, 60)
            if r is self.room:
                col = WHITE if blink(self.t, 30) else (200, 200, 200)
            s.fill(col, (x0 + pos[0] * (cw + gap), y0 + pos[1] * (ch + gap), cw, ch))

    def draw(self, s):
        self.draw_world(s, self.floor.background(self.room))
        n = self.run.floor + 1
        boss = self.boss if (self.boss and self.room.kind == "boss" and not self.room.cleared) else None
        if not self.draw_hud(s, self.stage["name"], "STAGE %d/12  %07d" % (n, self.run.score), boss):
            self.draw_minimap(s)
        if self.fade:
            a = int(255 * (1 - abs(self.fade - 10) / 10))
            veil = pygame.Surface((W, H - HUD_H))
            veil.set_alpha(a)
            s.blit(veil, (0, HUD_H))
        if self.paused:
            self.draw_pause(s)


# ======================================================================= car bonus stage

class Car:
    """The bonus-stage car: a big breakable target that is also a wall."""

    def __init__(self, x, y):
        self.x, self.y = float(x), float(y)
        self.max_hp = self.hp = 260
        self.half_w = 52
        self.depth_pad = 10
        self.stage = 0
        self.images = [sprites.car_sprite(i) for i in range(5)]
        self.flash = 0
        self.jiggle = 0
        self.dead = False
        self.rect = pygame.Rect(int(x - 50), int(y - 14), 100, 14)
        self.z = 0
        self.visible = True

    @property
    def sort_y(self):
        return self.y

    def car_hit(self, scene, dmg, move):
        if self.hp <= 0:
            return False
        self.hp -= dmg
        self.jiggle = 6
        scene.hitstop = max(scene.hitstop, 3)
        scene.spark(scene.player.x + scene.player.facing * 14, scene.player.y - 18)
        new_stage = min(4, int((1 - self.hp / self.max_hp) * 4.0 + 0.0001))
        if self.hp <= 0:
            new_stage = 4
        rng = scene.fx_rng
        for _ in range(3):
            scene.effects.append(Debris(self.x + rng.uniform(-40, 40), self.y - 20, (200, 30, 35), rng))
        if new_stage != self.stage:
            self.stage = new_stage
            scene.sfx("glass")
            scene.shake = 8
            for _ in range(14):
                scene.effects.append(Debris(self.x + rng.uniform(-40, 40), self.y - 24,
                                            rng.choice(((150, 210, 240), (200, 30, 35), (40, 40, 40))), rng))
        scene.sfx("car", 0.8)
        if self.hp <= 0:
            scene.on_car_destroyed()
        return True

    def draw(self, surf, ox=0, oy=0):
        img = self.images[self.stage]
        j = (self.jiggle % 2) * 2 - 1 if self.jiggle else 0
        if self.jiggle:
            self.jiggle -= 1
        surf.blit(img, (int(self.x) - img.get_width() // 2 + j + ox, int(self.y) - img.get_height() + 4 + oy))


class CarScene(CombatScene):
    music = "stage"
    TIME = 45

    def __init__(self, game, run):
        super().__init__(game, run)
        self.bounds = (PLAY_L, 104, PLAY_R, PLAY_B)
        self.player = Player(70, 140, run.char, run)
        self.player.ki = run.ki
        self.car = Car(MID_X + 30, 132)
        self.extra_targets = [self.car]
        self.solids = [self.car.rect]
        self.proj_blockers = []
        self.time_left = self.TIME * 60
        self.finished = 0
        self.destroyed = False
        self.spawn_t = 240
        self.rng = random.Random(run.rng.randrange(1 << 30))
        self.bg = self.render_bg()
        self.intro = 90
        self.banner("BONUS STAGE", 70, YELLOW, 2, 60)
        self.banner("SMASH THE CAR!", 70, WHITE, 1, 80)

    def render_bg(self):
        rng = random.Random(11)
        s = pygame.Surface((W, H))
        draw_backdrop(s, (90, 140, 210), (230, 180, 140))
        x = 0
        while x < W:
            w = rng.randrange(30, 60)
            h = rng.randrange(40, 70)
            col = rng.choice(((120, 90, 80), (150, 130, 110), (90, 90, 110), (170, 150, 120)))
            s.fill(col, (x, 92 - h, w - 2, h))
            for wy in range(92 - h + 5, 86, 9):
                for wx in range(x + 4, x + w - 8, 8):
                    s.fill((60, 70, 90) if rng.random() < 0.7 else (250, 230, 150), (wx, wy, 4, 5))
            x += w
        s.fill((170, 165, 160), (0, 90, W, 14))       # sidewalk
        for xx in range(0, W, 16):
            s.fill((140, 135, 130), (xx, 90, 1, 14))
        s.fill((110, 105, 100), (0, 103, W, 2))       # curb
        s.fill((70, 68, 72), (0, 105, W, H - 105))    # road
        for xx in range(0, W, 40):
            s.fill((230, 210, 90), (xx + 8, 150, 20, 2))
        for _ in range(300):
            s.fill((80, 78, 84), (rng.randrange(W), rng.randrange(106, H), 1, 1))
        return s

    def on_car_destroyed(self):
        self.destroyed = True
        self.finished = 1
        self.banner("PERFECT!", 150, YELLOW, 3, 56)
        self.float_text("OH! MY CAR!", self.car.x + 40, self.car.y - 50, (255, 255, 255), 120)
        self.sfx("ko")
        for e in self.enemies:
            if not e.dead:
                e.die(1, self)

    def update(self, inp):
        super().update(inp)
        if self.paused:
            self.update_pause(inp)
            return
        if (inp.pressed("start") or inp.pressed("back")) and not self.player_dead_t and not self.finished:
            self.paused = True
            self.pause_sel = 0
            return
        if self.intro > 0:
            self.intro -= 1
            for b in self.banners:
                b[1] -= 1
            self.banners = [b for b in self.banners if b[1] > 0]
            return
        if not self.update_world(inp):
            return
        if self.finished:
            self.finished += 1
            if self.finished > 170:
                self.finish()
            return
        self.time_left -= 1
        if self.time_left <= 0:
            self.finished = 1
            self.banner("TIME OVER", 150, (255, 120, 60), 3, 56)
            self.sfx("denied")
            for e in self.enemies:
                if not e.dead:
                    e.die(1, self)
            return
        self.spawn_t -= 1
        alive = [e for e in self.enemies if not e.dead]
        if self.spawn_t <= 0 and len(alive) < 2:
            self.spawn_t = self.rng.randint(240, 400)
            side = self.rng.choice((PLAY_L + 8, PLAY_R - 8))
            name = self.rng.choice(("MAD GEAR THUG", "SHADALOO GRUNT"))
            e = Enemy(side, self.rng.uniform(110, PLAY_B - 4), name, self.run.floor, self.rng)
            self.enemies.append(e)
            self.puff(e.x, e.y)

    def finish(self):
        p = self.player
        bonus = (self.time_left // 60) * 100 + (5000 if self.destroyed else int(2000 * (1 - self.car.hp / self.car.max_hp)))
        self.run.score += bonus
        if self.destroyed:
            p.hp = p.max_hp
        else:
            p.hp = min(p.max_hp, p.hp + int(p.max_hp * 0.3))
        self.run.hp = p.hp
        self.run.ki = p.ki
        self.run.bonus_done = True
        self.game.change(StageIntroScene(self.game, self.run))

    def drawables(self):
        items = super().drawables()
        items.append(self.car)
        return items

    def draw(self, s):
        self.draw_world(s, self.bg)
        secs = max(0, self.time_left // 60)
        self.draw_hud(s, "BONUS STAGE", "TIME %02d  %07d" % (secs, self.run.score))
        draw_text(s, "CAR", W - 4, 2, WHITE, shadow=None, align="right")
        self._bar(s, W - 100, 10, 96, 5, self.car.hp / self.car.max_hp, (255, 120, 40), (60, 20, 20),
                  rtl=True)
        if self.paused:
            self.draw_pause(s)


# ======================================================================= perks

class PerkScene(Scene):
    music = "title"

    def __init__(self, game, run):
        super().__init__(game)
        self.run = run
        self.choices = run.offer_perks(3)
        self.sel = 0
        self.done = 0

    def update(self, inp):
        super().update(inp)
        if self.done:
            self.done += 1
            if self.done > 30:
                self.advance()
            return
        if not self.choices:
            if self.t > 30:
                self.advance()
            return
        if inp.pressed("left"):
            self.sel = (self.sel - 1) % len(self.choices)
            self.sfx("select")
        if inp.pressed("right"):
            self.sel = (self.sel + 1) % len(self.choices)
            self.sfx("select")
        if self.t > 20 and inp.any_confirm():
            k = self.choices[self.sel]
            self.run.perks.append(k)
            if k == "body":
                self.run.hp = (self.run.hp or 0) + 25
            self.sfx("perk")
            self.done = 1

    def advance(self):
        run = self.run
        run.floor += 1
        if run.floor >= len(run.order):
            self.game.change(GameOverScene(self.game, run, True))
        elif run.floor == BONUS_AFTER_FLOOR and not run.bonus_done:
            self.game.change(CarScene(self.game, run))
        else:
            self.game.change(StageIntroScene(self.game, run))

    def draw(self, s):
        draw_backdrop(s, (20, 30, 60), (50, 20, 60))
        draw_text(s, "STAGE CLEAR!", W // 2, 10, YELLOW, 2, align="center")
        draw_text(s, "CHOOSE A NEW TECHNIQUE", W // 2, 32, WHITE, align="center")
        cw, gap = 94, 8
        x0 = (W - (cw * 3 + gap * 2)) // 2
        for i, k in enumerate(self.choices):
            name, desc, _ = PERKS[k]
            x = x0 + i * (cw + gap)
            y = 50
            sel = i == self.sel
            s.fill((30, 25, 50) if not sel else (70, 40, 90), (x, y, cw, 100))
            pygame.draw.rect(s, (255, 210, 80) if sel else (100, 90, 130), (x, y, cw, 100), 1)
            s.blit(sprites.item_sprite("scroll"), (x + cw // 2 - 7, y + 6))
            for j, line in enumerate(wrap(name, 15)):
                draw_text(s, line, x + cw // 2, y + 26 + j * 9, (255, 220, 120), align="center")
            for j, line in enumerate(wrap(desc, 15)):
                draw_text(s, line, x + cw // 2, y + 50 + j * 9, WHITE, shadow=None, align="center")
        if not self.choices:
            draw_text(s, "YOU HAVE MASTERED EVERYTHING!", W // 2, 90, WHITE, align="center")
        draw_text(s, "LEFT/RIGHT TO PICK, PUNCH TO LEARN", W // 2, 160, (180, 180, 200), align="center")
        nxt = self.run.floor + 1
        if nxt < len(self.run.order):
            label = "BONUS STAGE" if nxt == BONUS_AFTER_FLOOR and not self.run.bonus_done else \
                STAGES[self.run.order[nxt]]["name"]
            draw_text(s, "NEXT: " + label, W // 2, 170, (150, 150, 180), align="center", shadow=None)


# ======================================================================= endings

class GameOverScene(Scene):
    def __init__(self, game, run, won):
        self.music = "title" if won else None
        super().__init__(game)
        if not won:
            game.audio.stop_music()
        self.run = run
        self.won = won
        data = save.load()
        self.new_high = run.score > data.get("high", 0)
        if self.new_high:
            data["high"] = run.score
        if won:
            data["wins"] = data.get("wins", 0) + 1
        save.store(data)
        self.fs = sprites.fighter_sprites(run.char["key"], run.char["look"])

    def update(self, inp):
        super().update(inp)
        if self.t > 60 and inp.any_confirm():
            self.game.change(TitleScene(self.game))

    def draw(self, s):
        run = self.run
        if self.won:
            draw_backdrop(s, (40, 30, 90), (220, 120, 60))
            draw_text(s, "YOU WIN!", W // 2, 10, YELLOW, 3, shadow=(150, 30, 30), align="center")
            s.blit(big_sprite(self.fs, "victory", 1), (W // 2 - 48, 34))
            draw_text(s, "CONGRATULATIONS! " + run.char["name"] + " IS THE", W // 2, 124, WHITE, align="center")
            draw_text(s, "NEW WORLD WARRIOR!", W // 2, 133, WHITE, align="center")
        else:
            draw_backdrop(s, (10, 5, 10), (70, 10, 20))
            draw_text(s, "YOU LOSE", W // 2, 14, (255, 70, 50), 3, shadow=(60, 0, 0), align="center")
            s.blit(big_sprite(self.fs, "down", 1), (W // 2 - 48, 30))
            st = run.stage if run.floor < len(run.order) else STAGES[run.order[-1]]
            draw_text(s, "FELL ON STAGE %d: %s" % (run.floor + 1, st["name"]), W // 2, 124, WHITE,
                      align="center")
        secs = run.frames // 60
        draw_text(s, "KOS %d   TIME %d:%02d   SCORE %07d" % (run.kills, secs // 60, secs % 60, run.score),
                  W // 2, 145, (255, 220, 140), align="center")
        if self.new_high:
            draw_text(s, "NEW HIGH SCORE!", W // 2, 155, YELLOW if blink(self.t, 20) else WHITE,
                      align="center")
        if self.t > 60 and blink(self.t):
            draw_text(s, "PRESS START", W // 2, 168, WHITE, align="center")
