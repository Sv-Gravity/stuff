"""Keyboard + gamepad input mapped to arcade actions."""

import pygame

KEYMAP = {
    "up": (pygame.K_UP, pygame.K_w),
    "down": (pygame.K_DOWN, pygame.K_s),
    "left": (pygame.K_LEFT, pygame.K_a),
    "right": (pygame.K_RIGHT, pygame.K_d),
    "punch": (pygame.K_j, pygame.K_z),
    "kick": (pygame.K_k, pygame.K_x),
    "special": (pygame.K_l, pygame.K_c),
    "start": (pygame.K_RETURN, pygame.K_KP_ENTER),
    "back": (pygame.K_ESCAPE, pygame.K_BACKSPACE),
}
KEY_TO_ACTION = {k: a for a, ks in KEYMAP.items() for k in ks}

# Typical SDL gamepad layout (Xbox / 8BitDo / PS in XInput mode)
JOY_BUTTONS = {0: "punch", 1: "kick", 2: "special", 3: "special", 4: "punch", 5: "kick",
               6: "back", 7: "start", 8: "back", 9: "start"}
DIRECTIONS = ("up", "down", "left", "right")
DEADZONE = 0.45


class Input:
    def __init__(self):
        self._pressed = set()
        self._held = set()
        self.virtual = set()       # held actions injected by tests / demo
        self.joysticks = {}
        try:
            for i in range(pygame.joystick.get_count()):
                self._add_joy(i)
        except pygame.error:
            pass

    def _add_joy(self, index):
        try:
            j = pygame.joystick.Joystick(index)
            j.init()
            self.joysticks[j.get_instance_id()] = j
        except (pygame.error, AttributeError):
            pass

    def new_frame(self):
        self._pressed = set()

    def handle(self, ev):
        if ev.type == pygame.KEYDOWN:
            a = KEY_TO_ACTION.get(ev.key)
            if a:
                self._pressed.add(a)
        elif ev.type == pygame.JOYBUTTONDOWN:
            a = JOY_BUTTONS.get(ev.button)
            if a:
                self._pressed.add(a)
        elif ev.type == getattr(pygame, "JOYDEVICEADDED", -1):
            self._add_joy(ev.device_index)
        elif ev.type == getattr(pygame, "JOYDEVICEREMOVED", -1):
            self.joysticks.pop(ev.instance_id, None)

    def update_held(self):
        keys = pygame.key.get_pressed()
        held = set()
        for a, ks in KEYMAP.items():
            for k in ks:
                if keys[k]:
                    held.add(a)
                    break
        for j in self.joysticks.values():
            try:
                if j.get_numhats():
                    hx, hy = j.get_hat(0)
                    if hx < 0: held.add("left")
                    if hx > 0: held.add("right")
                    if hy > 0: held.add("up")
                    if hy < 0: held.add("down")
                if j.get_numaxes() >= 2:
                    ax, ay = j.get_axis(0), j.get_axis(1)
                    if ax < -DEADZONE: held.add("left")
                    if ax > DEADZONE: held.add("right")
                    if ay < -DEADZONE: held.add("up")
                    if ay > DEADZONE: held.add("down")
                for b, a in JOY_BUTTONS.items():
                    if b < j.get_numbuttons() and j.get_button(b):
                        held.add(a)
            except pygame.error:
                pass
        held |= self.virtual
        for d in DIRECTIONS:           # stick/hat taps count as presses for menus
            if d in held and d not in self._held:
                self._pressed.add(d)
        self._held = held

    def pressed(self, a):
        return a in self._pressed

    def held(self, a):
        return a in self._held

    def any_confirm(self):
        return self.pressed("start") or self.pressed("punch")

    def press(self, a):
        """Inject a single press (used by the automated tests)."""
        self._pressed.add(a)
