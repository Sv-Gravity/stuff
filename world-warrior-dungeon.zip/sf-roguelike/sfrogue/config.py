"""Screen layout and global constants.

Everything is drawn to a tiny 320x180 canvas and scaled up by SDL, which is
what keeps the game cheap enough to hold 60fps on a Raspberry Pi.
"""

W, H = 320, 180
FPS = 60

HUD_H = 20          # status bar at the top
TOP_WALL = 22       # visible wall face under the HUD (3/4 view)
SIDE_WALL = 12
BOTTOM_WALL = 8

PLAY_L = SIDE_WALL
PLAY_R = W - SIDE_WALL
PLAY_T = HUD_H + TOP_WALL
PLAY_B = H - BOTTOM_WALL
MID_X = W // 2
MID_Y = (PLAY_T + PLAY_B) // 2

DOOR_W = 30         # opening in the top/bottom walls
DOOR_H = 26         # opening in the side walls

GRID = 5            # floors are generated on a GRID x GRID map of rooms

WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
YELLOW = (255, 220, 40)
RED = (220, 40, 40)
ORANGE = (255, 140, 30)
BLUE = (70, 140, 255)
GREEN = (70, 210, 90)
GREY = (140, 140, 150)
DARK = (16, 12, 24)
