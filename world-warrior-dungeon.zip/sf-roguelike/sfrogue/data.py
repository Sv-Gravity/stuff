"""Game content: the roster, enemies from across the series, stages, perks.

Everything here is plain data so new characters/enemies are easy to add.
Art is procedural: a "look" is just a palette, a body build and a hair style.
"""

# ----------------------------------------------------------------- palette
SKIN = (232, 176, 128)
SKIN_TAN = (205, 140, 90)
SKIN_DARK = (140, 85, 50)
SKIN_DEEP = (100, 62, 40)
SKIN_PALE = (245, 205, 170)
WHITE = (240, 240, 240)
BLACK = (30, 30, 36)
RED = (205, 35, 35)
BLUE = (45, 70, 190)
GOLD = (230, 185, 50)
BROWN = (95, 60, 35)
BLOND = (240, 205, 70)


def L(skin, hair, style, top, bottom, build="normal", **kw):
    d = dict(skin=skin, hair=hair, style=style, top=top, bottom=bottom, build=build)
    d.update(kw)
    return d


# ----------------------------------------------------------------- roster
# Playable World Warriors. Only Ryu is complete; everyone else plays with the
# shared basic punch/kick set until their specials are built.
CHARACTERS = [
    dict(key="balrog", name="BALROG", country="USA", complete=False,
         hp=110, speed=1.35, power=1.15,
         specials=["DASH STRAIGHT", "DASH UPPER", "BUFFALO HEADBUTT"],
         look=L(SKIN_DEEP, BLACK, "short", SKIN_DEEP, BLUE, "big", legs=SKIN_DEEP,
                trunks=BLUE, gloves=BLUE, boots=BLUE)),
    dict(key="ryu", name="RYU", country="JAPAN", complete=True,
         hp=100, speed=1.45, power=1.0,
         specials=["PUNCH COMBO (3 HITS)", "KICK / ROUNDHOUSE", "HADOUKEN"],
         look=L(SKIN, (60, 40, 30), "short", WHITE, WHITE, gi=True, belt=BLACK,
                headband=(200, 30, 30), gloves=(150, 45, 35))),
    dict(key="honda", name="E.HONDA", country="JAPAN", complete=False,
         hp=130, speed=1.15, power=1.15,
         specials=["HUNDRED HAND SLAP", "SUMO HEADBUTT", "OICHO THROW"],
         look=L(SKIN_PALE, BLACK, "topknot", SKIN_PALE, (40, 60, 170), "huge",
                legs=SKIN_PALE, trunks=(40, 60, 170), belt=(40, 60, 170))),
    dict(key="blanka", name="BLANKA", country="BRAZIL", complete=False,
         hp=110, speed=1.5, power=1.05,
         specials=["ELECTRIC THUNDER", "ROLLING ATTACK", "BACKSTEP ROLL"],
         look=L((70, 165, 70), (240, 120, 30), "wild", (70, 165, 70), (150, 95, 40), "big",
                legs=(70, 165, 70), trunks=(150, 95, 40))),
    dict(key="guile", name="GUILE", country="USA", complete=False,
         hp=105, speed=1.35, power=1.05,
         specials=["SONIC BOOM", "FLASH KICK", "KNEE BAZOOKA"],
         look=L(SKIN, BLOND, "flattop", (85, 115, 60), (95, 115, 70), "big",
                boots=BLACK, belt=BLACK)),
    dict(key="vega", name="VEGA", country="SPAIN", complete=False,
         hp=90, speed=1.65, power=0.95,
         specials=["ROLLING CRYSTAL FLASH", "FLYING BARCELONA ATTACK", "SCARLET TERROR"],
         look=L(SKIN, BROWN, "ponytail", SKIN, (205, 160, 70), "slim",
                belt=(200, 40, 40), mask=True, claw=True, boots=(120, 60, 120))),
    dict(key="sagat", name="SAGAT", country="THAILAND", complete=False,
         hp=120, speed=1.3, power=1.2,
         specials=["TIGER SHOT", "TIGER UPPERCUT", "TIGER KNEE"],
         look=L(SKIN_TAN, BLACK, "bald", SKIN_TAN, (60, 60, 160), "huge",
                legs=SKIN_TAN, trunks=(60, 60, 160), eyepatch=True)),
    dict(key="ken", name="KEN", country="USA", complete=False,
         hp=100, speed=1.5, power=1.0,
         specials=["HADOUKEN", "SHORYUKEN", "TATSUMAKI SENPUKYAKU"],
         look=L(SKIN, BLOND, "long", (210, 35, 35), (210, 35, 35), gi=True, belt=BLACK,
                gloves=BLACK)),
    dict(key="chunli", name="CHUN-LI", country="CHINA", complete=False,
         hp=90, speed=1.7, power=0.95,
         specials=["LIGHTNING LEGS", "SPINNING BIRD KICK", "KIKOKEN"],
         look=L(SKIN, BROWN, "buns", (45, 75, 185), (45, 75, 185), "slim",
                legs=(140, 95, 60), belt=GOLD, boots=WHITE, sleeves=False)),
    dict(key="zangief", name="ZANGIEF", country="USSR", complete=False,
         hp=140, speed=1.1, power=1.3,
         specials=["SPINNING PILEDRIVER", "DOUBLE LARIAT", "BANISHING FLAT"],
         look=L(SKIN_PALE, (90, 45, 30), "mohawk", SKIN_PALE, (200, 40, 40), "huge",
                legs=SKIN_PALE, trunks=(200, 40, 40), boots=(200, 40, 40), beard=True,
                gloves=GOLD)),
    dict(key="dhalsim", name="DHALSIM", country="INDIA", complete=False,
         hp=90, speed=1.25, power=1.0,
         specials=["YOGA FIRE", "YOGA FLAME", "YOGA TELEPORT"],
         look=L(SKIN_DARK, BLACK, "bald", SKIN_DARK, (230, 160, 40), "lanky",
                legs=SKIN_DARK, trunks=(230, 160, 40), gloves=(240, 240, 220))),
    dict(key="bison", name="M.BISON", country="THAILAND", complete=False,
         hp=115, speed=1.4, power=1.15,
         specials=["PSYCHO CRUSHER", "SCISSOR KICK", "HEAD STOMP"],
         look=L(SKIN, BLACK, "cap", (165, 30, 40), (165, 30, 40), "big", sleeves=True,
                boots=BLACK, gloves=BLACK, belt=GOLD, cap=(165, 30, 40), cape=(60, 20, 30))),
]
CHAR_BY_KEY = {c["key"]: c for c in CHARACTERS}

# ----------------------------------------------------------------- bosses
# Each stage is ruled by its SF2 owner. Move names map to behaviours in
# entities.py (proj, charge, aura, upper, teleport, grab, long, jab, kick).
BOSS_MOVES = {
    "ryu": [("jab", 3), ("kick", 3), ("proj", 3), ("upper", 2), ("tatsu", 2)],
    "ken": [("jab", 3), ("kick", 3), ("proj", 2), ("upper", 3), ("tatsu", 2)],
    "honda": [("jab", 2), ("slaps", 3), ("charge", 3)],
    "chunli": [("kick", 4), ("legs", 3), ("proj", 2), ("bird", 2)],
    "blanka": [("jab", 2), ("electric", 3), ("roll", 3)],
    "zangief": [("jab", 2), ("lariat", 3), ("grab", 4)],
    "guile": [("jab", 2), ("kick", 2), ("proj", 4), ("upper", 3)],
    "dhalsim": [("long", 4), ("proj", 3), ("teleport", 2)],
    "balrog": [("jab", 3), ("charge", 4), ("upper", 2)],
    "vega": [("kick", 3), ("charge", 3), ("teleport", 3)],
    "sagat": [("kick", 3), ("spread", 4), ("upper", 3)],
    "bison": [("kick", 2), ("psycho", 4), ("teleport", 2), ("proj", 2)],
}
BOSS_PROJ = {   # projectile kind, colour, name
    "ryu": ("orb", (80, 150, 255), "HADOUKEN"),
    "ken": ("orb", (255, 150, 60), "HADOUKEN"),
    "chunli": ("orb", (120, 200, 255), "KIKOKEN"),
    "guile": ("crescent", (255, 230, 90), "SONIC BOOM"),
    "dhalsim": ("flame", (255, 140, 30), "YOGA FIRE"),
    "sagat": ("orb", (255, 200, 60), "TIGER SHOT"),
    "bison": ("orb", (180, 70, 255), "PSYCHO SHOT"),
}

# ----------------------------------------------------------------- enemies
# Fighters from every game in the series. arch: brawler, rushdown,
# grappler, zoner, kicker, ninja.
ENEMIES = {
    # Street Fighter (1987)
    "RETSU": dict(game="SF", arch="brawler", look=L(SKIN, BLACK, "bald", (210, 170, 60), (210, 170, 60), gi=True, belt=BLACK)),
    "GEKI": dict(game="SF", arch="ninja", look=L(SKIN, BLACK, "hood", (60, 60, 75), (60, 60, 75), hood=(60, 60, 75), claw=True)),
    "JOE": dict(game="SF", arch="kicker", look=L(SKIN, BLOND, "short", WHITE, (190, 40, 40), headband=(40, 40, 40))),
    "MIKE": dict(game="SF", arch="brawler", look=L(SKIN_DEEP, BLACK, "bald", SKIN_DEEP, (220, 210, 40), "big", legs=SKIN_DEEP, trunks=(220, 210, 40), gloves=RED)),
    "LEE": dict(game="SF", arch="kicker", look=L(SKIN, BLACK, "short", (230, 230, 120), (40, 40, 40), sleeves=True)),
    "GEN": dict(game="ALPHA", arch="rushdown", look=L(SKIN_PALE, WHITE, "short", (215, 200, 160), (215, 200, 160), "lanky", sleeves=True, beard=True)),
    "EAGLE": dict(game="SF", arch="brawler", look=L(SKIN_PALE, (60, 40, 30), "short", (120, 20, 40), (40, 40, 50), sleeves=True)),
    "ADON": dict(game="SF", arch="rushdown", look=L(SKIN_TAN, BLACK, "spiky", SKIN_TAN, (70, 70, 180), legs=SKIN_TAN, trunks=(70, 70, 180))),
    "BIRDIE": dict(game="SF", arch="grappler", look=L(SKIN_DEEP, BLOND, "mohawk", (40, 40, 45), (40, 40, 45), "huge", gloves=GOLD)),
    # Street Fighter II era additions
    "FEI LONG": dict(game="SF2", arch="rushdown", look=L(SKIN, BLACK, "short", SKIN, BLACK, legs=BLACK, belt=GOLD)),
    "DEE JAY": dict(game="SF2", arch="kicker", look=L(SKIN_DEEP, BLACK, "short", SKIN_DEEP, (240, 200, 40), legs=(240, 200, 40), boots=RED)),
    "CAMMY": dict(game="SF2", arch="rushdown", look=L(SKIN, BLOND, "ponytail", (40, 120, 60), SKIN, "slim", legs=SKIN, boots=(200, 40, 40), gloves=(200, 40, 40))),
    "T.HAWK": dict(game="SF2", arch="grappler", look=L(SKIN_DARK, BLACK, "long", (60, 120, 210), (220, 200, 150), "huge")),
    # Alpha series
    "DAN": dict(game="ALPHA", arch="brawler", look=L(SKIN, BLACK, "short", (240, 140, 170), (240, 140, 170), gi=True, belt=BLACK)),
    "SAKURA": dict(game="ALPHA", arch="brawler", look=L(SKIN, BROWN, "short", WHITE, (40, 50, 140), "slim", headband=RED, legs=SKIN)),
    "KARIN": dict(game="ALPHA", arch="kicker", look=L(SKIN_PALE, BLOND, "long", (200, 30, 40), (200, 30, 40), "slim", sleeves=True, legs=(240, 240, 240))),
    "R.MIKA": dict(game="ALPHA", arch="grappler", look=L(SKIN, BLOND, "ponytail", (50, 90, 210), (50, 90, 210), "small", legs=SKIN, boots=WHITE)),
    "GUY": dict(game="ALPHA", arch="rushdown", look=L(SKIN, BLACK, "short", (220, 120, 40), (220, 120, 40), gi=True, belt=BLACK)),
    "CODY": dict(game="ALPHA", arch="brawler", look=L(SKIN, BLOND, "short", WHITE, (60, 90, 170), gloves=BLACK)),
    "SODOM": dict(game="ALPHA", arch="grappler", look=L(SKIN, BLACK, "hood", (40, 40, 90), (40, 40, 90), "big", hood=(200, 200, 210), mask=True)),
    "ROLENTO": dict(game="ALPHA", arch="rushdown", look=L(SKIN, BLOND, "cap", (90, 110, 70), (90, 110, 70), sleeves=True, cap=(110, 60, 120), boots=BLACK)),
    "ROSE": dict(game="ALPHA", arch="zoner", look=L(SKIN_PALE, (120, 40, 80), "long", (90, 30, 90), (90, 30, 90), "slim", sleeves=True), proj=("orb", (230, 120, 255))),
    "JULI": dict(game="ALPHA", arch="rushdown", look=L(SKIN, BROWN, "cap", (110, 60, 130), SKIN, "slim", legs=SKIN, cap=(110, 60, 130), boots=(110, 60, 130))),
    "JUNI": dict(game="ALPHA", arch="rushdown", look=L(SKIN, BROWN, "cap", (60, 110, 170), SKIN, "slim", legs=SKIN, cap=(60, 110, 170), boots=(60, 110, 170))),
    # Street Fighter III
    "ALEX": dict(game="SF3", arch="grappler", look=L(SKIN, BLOND, "short", WHITE, (60, 120, 70), "big", headband=RED, boots=BROWN)),
    "DUDLEY": dict(game="SF3", arch="brawler", look=L(SKIN_DEEP, BLACK, "short", SKIN_DEEP, (30, 30, 40), legs=(30, 30, 40), gloves=RED)),
    "ELENA": dict(game="SF3", arch="kicker", look=L(SKIN_DEEP, WHITE, "short", WHITE, SKIN_DEEP, "slim", legs=SKIN_DEEP, trunks=WHITE)),
    "IBUKI": dict(game="SF3", arch="ninja", look=L(SKIN, BROWN, "ponytail", (60, 60, 80), (60, 60, 80), "slim", hood=(60, 60, 80))),
    "MAKOTO": dict(game="SF3", arch="brawler", look=L(SKIN, BLACK, "short", WHITE, WHITE, "small", gi=True, belt=GOLD, headband=GOLD)),
    "NECRO": dict(game="SF3", arch="zoner", look=L((150, 160, 170), BLACK, "bald", BLACK, BLACK, "lanky", legs=BLACK), proj=("crescent", (120, 220, 255))),
    "HUGO": dict(game="SF3", arch="grappler", look=L(SKIN_PALE, (230, 210, 120), "short", (130, 60, 130), (130, 60, 130), "huge", boots=BLACK)),
    "URIEN": dict(game="SF3", arch="zoner", look=L(SKIN_TAN, BLOND, "spiky", SKIN_TAN, BLACK, "big", legs=SKIN_TAN, trunks=BLACK), proj=("orb", (120, 255, 160))),
    "REMY": dict(game="SF3", arch="zoner", look=L(SKIN_PALE, (150, 170, 220), "long", (40, 40, 60), (60, 60, 80), "slim", sleeves=True), proj=("crescent", (120, 200, 255))),
    "Q": dict(game="SF3", arch="brawler", look=L((200, 200, 210), BLACK, "hood", (110, 90, 70), (110, 90, 70), "big", hood=(110, 90, 70), sleeves=True)),
    "TWELVE": dict(game="SF3", arch="ninja", look=L((235, 235, 245), WHITE, "bald", (235, 235, 245), (235, 235, 245), "lanky", legs=(235, 235, 245))),
    "ORO": dict(game="SF3", arch="zoner", look=L(SKIN_TAN, WHITE, "bald", SKIN_TAN, (90, 70, 50), "small", legs=SKIN_TAN, trunks=(90, 70, 50), beard=True), proj=("orb", (120, 255, 200))),
    "YUN": dict(game="SF3", arch="rushdown", look=L(SKIN, BLACK, "cap", WHITE, (70, 70, 80), sleeves=True, cap=(230, 230, 230))),
    "YANG": dict(game="SF3", arch="kicker", look=L(SKIN, BLACK, "short", (230, 230, 230), (70, 70, 80), sleeves=True)),
    "SEAN": dict(game="SF3", arch="brawler", look=L(SKIN_TAN, BLACK, "short", (230, 220, 160), (230, 220, 160), gi=True, belt=BLACK)),
    "GILL": dict(game="SF3", arch="zoner", look=L((220, 60, 60), BLOND, "long", (220, 60, 60), (40, 90, 220), "big", legs=(40, 90, 220), trunks=WHITE), proj=("orb", (255, 120, 60))),
    # Street Fighter IV
    "ABEL": dict(game="SF4", arch="grappler", look=L(SKIN, BROWN, "short", (220, 220, 225), (60, 60, 70), "big", sleeves=True, boots=BLACK)),
    "C.VIPER": dict(game="SF4", arch="rushdown", look=L(SKIN, (180, 40, 40), "long", BLACK, BLACK, "slim", sleeves=True, gloves=(60, 60, 60))),
    "EL FUERTE": dict(game="SF4", arch="rushdown", look=L(SKIN_TAN, BLACK, "hood", SKIN_TAN, (220, 60, 30), "small", hood=(40, 160, 70), mask=True, legs=(220, 60, 30))),
    "RUFUS": dict(game="SF4", arch="brawler", look=L(SKIN_PALE, BLACK, "long", (240, 200, 40), BLACK, "huge", sleeves=True)),
    "SETH": dict(game="SF4", arch="zoner", look=L((90, 150, 230), BLACK, "bald", (90, 150, 230), BLACK, "big", legs=BLACK), proj=("orb", (80, 180, 255))),
    "JURI": dict(game="SF4", arch="kicker", look=L(SKIN_PALE, BLACK, "buns", (150, 60, 160), (150, 60, 160), "slim", legs=SKIN_PALE)),
    "HAKAN": dict(game="SF4", arch="grappler", look=L((200, 60, 50), BLACK, "bald", (200, 60, 50), (240, 200, 80), "huge", legs=(240, 200, 80))),
    # Street Fighter V
    "RASHID": dict(game="SF5", arch="zoner", look=L(SKIN_TAN, BLACK, "short", WHITE, (60, 60, 70), sleeves=True, headband=(60, 160, 120)), proj=("crescent", (200, 255, 230))),
    "LAURA": dict(game="SF5", arch="grappler", look=L(SKIN_TAN, (140, 60, 120), "ponytail", (90, 200, 120), (50, 50, 60), legs=(50, 50, 60))),
    "NECALLI": dict(game="SF5", arch="rushdown", look=L(SKIN_DARK, BLACK, "wild", SKIN_DARK, (110, 60, 30), "big", legs=SKIN_DARK, trunks=(110, 60, 30))),
    "F.A.N.G": dict(game="SF5", arch="zoner", look=L(SKIN_PALE, BLACK, "cap", (110, 30, 120), (110, 30, 120), "lanky", sleeves=True, cap=(110, 30, 120)), proj=("orb", (160, 255, 80))),
    "NASH": dict(game="SF5", arch="zoner", look=L((140, 190, 150), BLOND, "flattop", (60, 90, 60), (60, 90, 60), "big", boots=BLACK), proj=("crescent", (255, 230, 90))),
    "KOLIN": dict(game="SF5", arch="kicker", look=L(SKIN_PALE, WHITE, "long", (120, 140, 160), (120, 140, 160), "slim", sleeves=True)),
    "ED": dict(game="SF5", arch="brawler", look=L(SKIN_PALE, BLOND, "short", (40, 40, 50), (40, 40, 50), sleeves=True, gloves=(40, 40, 50))),
    "ABIGAIL": dict(game="SF5", arch="grappler", look=L(SKIN_PALE, (200, 40, 40), "mohawk", (140, 140, 150), (60, 60, 70), "huge")),
    "MENAT": dict(game="SF5", arch="zoner", look=L(SKIN_TAN, (70, 50, 120), "long", (70, 50, 120), (70, 50, 120), "slim"), proj=("orb", (180, 120, 255))),
    # Street Fighter 6
    "LUKE": dict(game="SF6", arch="brawler", look=L(SKIN, (90, 60, 40), "short", (60, 90, 60), (50, 50, 60), gloves=(80, 80, 80))),
    "JAMIE": dict(game="SF6", arch="rushdown", look=L(SKIN, BLACK, "ponytail", (230, 230, 230), (40, 40, 60), headband=(60, 160, 200))),
    "KIMBERLY": dict(game="SF6", arch="ninja", look=L(SKIN_DEEP, (240, 140, 40), "ponytail", (240, 140, 40), (60, 60, 80), "slim")),
    "MARISA": dict(game="SF6", arch="brawler", look=L(SKIN_PALE, BLOND, "long", GOLD, (200, 60, 40), "huge", legs=SKIN_PALE, trunks=(200, 60, 40))),
    "MANON": dict(game="SF6", arch="grappler", look=L(SKIN_DEEP, BLACK, "buns", WHITE, WHITE, "slim", belt=BLACK, gi=True)),
    "JP": dict(game="SF6", arch="zoner", look=L(SKIN_PALE, WHITE, "short", (40, 40, 60), (40, 40, 60), "lanky", sleeves=True), proj=("orb", (200, 80, 255))),
    "LILY": dict(game="SF6", arch="rushdown", look=L(SKIN_DARK, BLACK, "buns", (80, 160, 220), (80, 160, 220), "small", legs=(80, 160, 220))),
    "A.K.I.": dict(game="SF6", arch="zoner", look=L(SKIN_PALE, BLACK, "long", (130, 40, 160), BLACK, "slim", sleeves=True), proj=("orb", (140, 255, 90))),
    # Bonus-stage street gang
    "MAD GEAR THUG": dict(game="ALPHA", arch="brawler", look=L(SKIN, BLOND, "mohawk", (200, 200, 60), (60, 60, 140))),
    "SHADALOO GRUNT": dict(game="SF2", arch="brawler", look=L(SKIN, BLACK, "cap", (130, 120, 90), (130, 120, 90), sleeves=True, cap=(130, 120, 90), boots=BLACK)),
}

ARCH_STATS = {   # hp, damage, speed, preferred distance, moves
    "brawler": (34, 6, 0.95, 16, ["jab", "jab", "kick"]),
    "rushdown": (28, 6, 1.25, 18, ["jab", "dash"]),
    "grappler": (48, 7, 0.75, 14, ["jab", "grab"]),
    "zoner": (26, 6, 0.85, 90, ["proj", "kick"]),
    "kicker": (30, 7, 1.0, 20, ["kick", "kick", "jab"]),
    "ninja": (26, 5, 1.15, 70, ["star", "teleport", "jab"]),
}

# ----------------------------------------------------------------- stages
# 12 floors = the 12 fights of a Street Fighter II Champion Edition run.
# The first 8 come in random order, then the four Grand Masters.
STAGES = {
    "ryu": dict(name="SUZAKU CASTLE", place="JAPAN", floor="planks", wall="castle",
                fa=(130, 85, 50), fb=(110, 70, 42), wc=(225, 220, 205), wd=(70, 45, 35),
                acc=(200, 40, 40), obst="lantern", music="stage",
                enemies=["RETSU", "GEKI", "GEN", "IBUKI", "MAKOTO"]),
    "ken": dict(name="HARBOR DOCKS", place="USA", floor="planks", wall="harbor",
                fa=(120, 105, 90), fb=(100, 88, 76), wc=(40, 90, 170), wd=(60, 50, 45),
                acc=(240, 240, 240), obst="crate", music="stage",
                enemies=["JOE", "MIKE", "CODY", "GUY", "LUKE"]),
    "honda": dict(name="BATHHOUSE", place="JAPAN", floor="tiles", wall="bath",
                  fa=(200, 215, 230), fb=(165, 185, 205), wc=(120, 180, 240), wd=(120, 80, 50),
                  acc=(240, 240, 250), obst="bucket", pool=(70, 150, 220), music="stage",
                  enemies=["DAN", "SAKURA", "KARIN", "HAKAN", "R.MIKA"]),
    "chunli": dict(name="MARKET STREET", place="CHINA", floor="stone", wall="market",
                   fa=(150, 145, 135), fb=(120, 115, 108), wc=(190, 40, 40), wd=(60, 100, 60),
                   acc=(250, 210, 60), obst="crate", music="stage",
                   enemies=["LEE", "YUN", "YANG", "JAMIE", "FEI LONG"]),
    "blanka": dict(name="AMAZON RIVER", place="BRAZIL", floor="grass", wall="jungle",
                   fa=(80, 140, 60), fb=(65, 115, 50), wc=(40, 110, 60), wd=(50, 90, 140),
                   acc=(250, 200, 80), obst="palm", pool=(60, 110, 150), music="stage",
                   enemies=["SEAN", "LAURA", "ELENA", "NECALLI", "EL FUERTE"]),
    "zangief": dict(name="STEEL FACTORY", place="USSR", floor="metal", wall="factory",
                    fa=(105, 105, 115), fb=(85, 85, 95), wc=(70, 65, 70), wd=(160, 50, 40),
                    acc=(240, 180, 40), obst="drum", music="stage",
                    enemies=["NECRO", "HUGO", "KOLIN", "BIRDIE", "ABIGAIL"]),
    "guile": dict(name="AIR BASE", place="USA", floor="concrete", wall="hangar",
                  fa=(150, 150, 145), fb=(135, 135, 130), wc=(110, 120, 115), wd=(150, 200, 240),
                  acc=(240, 200, 40), obst="drum", music="stage",
                  enemies=["NASH", "ALEX", "ROLENTO", "KIMBERLY", "C.VIPER"]),
    "dhalsim": dict(name="MAHARAJA TEMPLE", place="INDIA", floor="tiles", wall="temple",
                    fa=(215, 150, 70), fb=(185, 110, 50), wc=(200, 110, 50), wd=(120, 60, 40),
                    acc=(120, 150, 170), obst="pillar", music="stage",
                    enemies=["RASHID", "ORO", "MENAT", "JP", "TWELVE"]),
    "balrog": dict(name="CASINO STRIP", place="LAS VEGAS", floor="carpet", wall="neon",
                   fa=(150, 30, 45), fb=(120, 22, 35), wc=(40, 20, 60), wd=(255, 80, 200),
                   acc=(80, 230, 255), obst="slot", music="stage",
                   enemies=["DUDLEY", "ABEL", "RUFUS", "ED", "MARISA"]),
    "vega": dict(name="FLAMENCO TAVERN", place="SPAIN", floor="terracotta", wall="fence",
                 fa=(190, 100, 60), fb=(165, 85, 50), wc=(90, 60, 50), wd=(170, 170, 180),
                 acc=(240, 200, 60), obst="table", music="stage",
                 enemies=["REMY", "ROSE", "LILY", "Q", "F.A.N.G"]),
    "sagat": dict(name="RECLINING BUDDHA", place="THAILAND", floor="grass", wall="buddha",
                  fa=(110, 150, 70), fb=(95, 130, 60), wc=(250, 160, 80), wd=(230, 180, 50),
                  acc=(60, 120, 60), obst="statue", music="stage",
                  enemies=["ADON", "EAGLE", "URIEN", "DEE JAY", "T.HAWK"]),
    "bison": dict(name="SHADALOO TEMPLE", place="THAILAND", floor="stone", wall="shadaloo",
                  fa=(80, 70, 95), fb=(62, 55, 75), wc=(55, 45, 70), wd=(150, 40, 160),
                  acc=(230, 190, 60), obst="pillar", music="boss",
                  enemies=["JURI", "SETH", "GILL", "JUNI", "JULI", "A.K.I.", "CAMMY", "SODOM"]),
}
WORLD_WARRIORS = ["ryu", "ken", "honda", "chunli", "blanka", "zangief", "guile", "dhalsim"]
GRAND_MASTERS = ["balrog", "vega", "sagat", "bison"]
BONUS_AFTER_FLOOR = 3     # the car stage comes after the 3rd fight, like the arcade

# ----------------------------------------------------------------- perks
# id: (name, description, stackable)
PERKS = {
    "fist": ("IRON FIST", "PUNCHES DEAL +25% DAMAGE", True),
    "legs": ("HURRICANE LEGS", "KICKS DEAL +25% DAMAGE AND REACH FURTHER", True),
    "focus": ("KI FOCUS", "HADOUKEN COSTS 30% LESS KI", True),
    "regen": ("SPIRIT FLOW", "KI REFILLS 60% FASTER", True),
    "body": ("IRON BODY", "+25 MAX HP AND HEAL 25", True),
    "feet": ("SWIFT FEET", "MOVE 15% FASTER", True),
    "shinku": ("SHINKU POWER", "HADOUKEN +50% DAMAGE AND BIGGER", True),
    "pierce": ("PIERCING KI", "HADOUKEN PASSES THROUGH ENEMIES", False),
    "twin": ("TWIN DRAGON", "HADOUKEN FIRES TWO FIREBALLS", False),
    "fury": ("SATSUI NO HADO", "HEAL 3 HP FOR EVERY KO", True),
    "skin": ("TOUGH SKIN", "TAKE 15% LESS DAMAGE", True),
    "combo": ("COMBO MASTER", "LANDING HITS GIVES DOUBLE KI", False),
    "chicken": ("ROAST CHICKEN", "FOOD HEALS TWICE AS MUCH", False),
}
