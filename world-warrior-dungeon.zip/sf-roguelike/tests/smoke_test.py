"""Headless end-to-end test: a bot plays a full run (all 12 floors + the car
bonus stage), then a run where the player dies. Reports frame timings.

    SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy python3 tests/smoke_test.py [screenshot_dir]
"""

import os
import random
import sys
import time
from collections import deque

os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pygame  # noqa: E402

from sfrogue.game import Game, open_window  # noqa: E402
from sfrogue.audio import Audio  # noqa: E402
from sfrogue import scenes  # noqa: E402
from sfrogue.world import DIRS  # noqa: E402

SHOTS = sys.argv[1] if len(sys.argv) > 1 else None
timings = []


def step(game, held=(), press=()):
    inp = game.inp
    inp.new_frame()
    pygame.event.pump()
    inp.virtual = set(held)
    inp.update_held()
    for a in press:
        inp.press(a)
    t0 = time.perf_counter()
    game.step()
    game.render()
    timings.append((time.perf_counter() - t0, type(game.scene).__name__))


def shot(game, name):
    if SHOTS:
        os.makedirs(SHOTS, exist_ok=True)
        img = pygame.transform.scale(game.canvas, (960, 540))
        pygame.image.save(img, os.path.join(SHOTS, name + ".png"))


_bot = {"last": None, "still": 0, "wander": 0, "dir": ("up",)}


def fight_inputs(scene, t):
    p = scene.player
    # crude unsticking: if we have not moved for a while, wander for a bit
    pos = (round(p.x), round(p.y))
    if p.state == "walk" and pos == _bot["last"]:
        _bot["still"] += 1
    else:
        _bot["still"] = 0
    _bot["last"] = pos
    if _bot["still"] > 20:
        _bot["wander"] = 45
        _bot["dir"] = random.choice([("up",), ("down",), ("up", "right"), ("down", "left"),
                                     ("up", "left"), ("down", "right")])
    if _bot["wander"] > 0:
        _bot["wander"] -= 1
        return set(_bot["dir"]), (["punch"] if t % 7 == 0 else [])
    targets = [e for e in scene.enemies if not e.dead and e.visible]
    targets += [b for b in scene.barrels if not b.dead]
    car = getattr(scene, "car", None)
    if car and car.hp > 0:
        targets.append(car)
    if not targets:
        return set(), []
    tgt = min(targets, key=lambda e: abs(e.x - p.x) + abs(e.y - p.y))
    ty = tgt.y + (16 if tgt is car else 0)
    dx, dy = tgt.x - p.x, ty - p.y
    held, press = set(), []
    reach = (tgt.half_w + 10) if tgt is car else 16
    if abs(dy) > 3:
        held.add("down" if dy > 0 else "up")
    if abs(dx) > reach:
        held.add("right" if dx > 0 else "left")
    elif (dx > 0) != (p.facing > 0) and tgt is not car:
        held.add("right" if dx > 0 else "left")
    elif abs(dy) <= 6 and t % 5 == 0:
        press.append("punch" if (t // 5) % 4 < 3 else "kick")
    if t % 97 == 0 and abs(dy) < 6:
        press.append("special")
    return held, press


def path_next(floor, cur, goal):
    prev = {cur: None}
    q = deque([cur])
    while q:
        c = q.popleft()
        if c == goal:
            break
        for v in DIRS.values():
            nb = (c[0] + v[0], c[1] + v[1])
            if nb in floor.rooms and nb not in prev:
                prev[nb] = c
                q.append(nb)
    node = goal
    while prev[node] != cur:
        node = prev[node]
    for name, v in DIRS.items():
        if (cur[0] + v[0], cur[1] + v[1]) == node:
            return node, name


def full_run(game, god=True):
    step(game)
    shot(game, "00_title")
    step(game, press=["start"])
    for _ in range(5):
        step(game)
    step(game, press=["left"])
    step(game, press=["right"])
    for _ in range(3):
        step(game)
    shot(game, "01_select")
    assert isinstance(game.scene, scenes.SelectScene)
    assert game.scene.current["key"] == "ryu"
    step(game, press=["punch"])
    for _ in range(60):
        step(game)
    assert isinstance(game.scene, scenes.StageIntroScene), game.scene
    stages_seen = []
    car_seen = False
    t = 0
    budget = 400000
    shot_rooms = set()
    while budget > 0:
        budget -= 1
        t += 1
        sc = game.scene
        if isinstance(sc, scenes.StageIntroScene):
            if sc.t == 40:
                shot(game, "%02d_intro_%s" % (10 + sc.run.floor, sc.run.stage_key))
            step(game, press=["start"] if sc.t > 40 else [])
            continue
        if isinstance(sc, scenes.PerkScene):
            if sc.t == 25:
                shot(game, "%02d_perk" % (10 + sc.run.floor))
            step(game, press=["punch"] if sc.t > 25 else [])
            continue
        if isinstance(sc, scenes.GameOverScene):
            shot(game, "99_ending_%s" % ("win" if sc.won else "lose"))
            return sc
        if isinstance(sc, scenes.TitleScene):
            raise AssertionError("bounced back to title unexpectedly")
        if god:
            sc.player.hp = sc.player.max_hp
        if isinstance(sc, scenes.CarScene):
            car_seen = True
            if sc.t == 400:
                shot(game, "%02d_car" % (10 + sc.run.floor))
            h, p = fight_inputs(sc, t)
            step(game, h, p)
            continue
        assert isinstance(sc, scenes.DungeonScene)
        if sc.run.stage_key not in stages_seen:
            stages_seen.append(sc.run.stage_key)
        room = sc.room
        key = (sc.run.floor, room.pos)
        if room.kind in ("fight", "boss") and key not in shot_rooms and sc.t > 0:
            if (room.kind == "boss" and sc.boss and sc.boss.frozen is False and sc.boss.hp < sc.boss.max_hp * 0.7) or \
                    (room.kind == "fight" and len(stages_seen) and sc.enemies and
                     all(e.spawn_t <= 0 for e in sc.enemies)):
                shot_rooms.add(key)
                if room.kind == "boss" or not any(k[0] == sc.run.floor and k != key for k in shot_rooms):
                    shot(game, "%02d_%s_%s" % (10 + sc.run.floor, room.kind, sc.run.stage_key))
        if sc.fade or sc.boss_intro:
            step(game)
            continue
        if not room.cleared:
            h, p = fight_inputs(sc, t)
            step(game, h, p)
            if os.environ.get("TRACE") and budget < 400 and budget % 10 == 0:
                e = [e for e in sc.enemies if not e.dead][0]
                print("T", sorted(h), p, round(sc.player.x, 1), round(sc.player.y, 1), sc.player.state,
                      "|", round(e.x, 1), round(e.y, 1), e.state, e.cool, e.engaged, e.hp)
            continue
        if room.kind == "boss":
            if sc.stairs:
                sc.leave_floor()
                step(game)
            else:
                step(game)
            continue
        nxt, via = path_next(sc.floor, room.pos, sc.floor.boss_pos)
        sc.go_to(nxt, via)
        step(game)
    sc = game.scene
    print("STUCK in", type(sc).__name__, "floor", sc.run.floor, getattr(sc, "room", None) and sc.room.kind)
    p = sc.player
    print(" player", round(p.x), round(p.y), p.state, p.hp)
    for e in sc.enemies:
        print(" enemy", e.name, round(e.x), round(e.y), e.state, e.hp, e.dead, e.visible, e.spawn_t, e.invuln)
    for b in sc.barrels:
        print(" barrel", b.x, b.y, b.dead)
    shot(game, "stuck")
    raise AssertionError("run did not finish")


def death_run(game):
    game.change(scenes.TitleScene(game))
    step(game)
    step(game, press=["start"])
    step(game)
    step(game, press=["punch"])
    for _ in range(200):
        if isinstance(game.scene, scenes.DungeonScene):
            break
        step(game, press=["start"] if game.scene.t > 40 else [])
    sc = game.scene
    assert isinstance(sc, scenes.DungeonScene)
    for _ in range(3000):
        sc = game.scene
        if isinstance(sc, scenes.GameOverScene):
            break
        if isinstance(sc, scenes.DungeonScene) and not sc.player.dead and sc.room.cleared:
            nxt, via = path_next(sc.floor, sc.room.pos, sc.floor.boss_pos)
            sc.go_to(nxt, via)
        if isinstance(sc, scenes.DungeonScene):
            sc.player.hp = min(sc.player.hp, 3)
        step(game)
    assert isinstance(game.scene, scenes.GameOverScene) and not game.scene.won, game.scene
    shot(game, "98_gameover")
    for _ in range(70):
        step(game)
    step(game, press=["start"])
    step(game)
    assert isinstance(game.scene, scenes.TitleScene)


def placeholder_check(game):
    """Every roster slot can be picked and fought with."""
    from sfrogue.data import CHARACTERS
    for c in CHARACTERS:
        run = scenes.Run(c, 5)
        sc = scenes.DungeonScene(game, run)
        game.scene = sc
        nxt, via = path_next(sc.floor, sc.room.pos, sc.floor.boss_pos)
        sc.go_to(nxt, via)
        for t in range(240):
            sc.player.hp = sc.player.max_hp
            h, p = fight_inputs(sc, t)
            step(game, h, p)


def main():
    pygame.mixer.pre_init(22050, -16, 1, 512)
    pygame.init()
    screen = open_window(False, True)
    t0 = time.perf_counter()
    audio = Audio(True)
    audio.prepare_music()
    print("audio ok=%s, synth time %.2fs" % (audio.ok, time.perf_counter() - t0))
    game = Game(screen, audio, seed=1234)
    end = full_run(game)
    r = end.run
    print("full run: won=%s floors=%d order=%s" % (end.won, r.floor, r.order))
    print("  kills=%d score=%d perks=%s frames=%d bonus=%s" % (r.kills, r.score, r.perks, r.frames, r.bonus_done))
    assert end.won and r.bonus_done
    death_run(game)
    print("death run: ok")
    placeholder_check(game)
    print("placeholder characters: ok")
    worst = sorted(timings, reverse=True)[:5]
    print("slowest frames:", [("%.1fms" % (d * 1000), n) for d, n in worst])
    ts = sorted(d for d, _ in timings)
    avg = sum(ts) / len(ts) * 1000
    p99 = ts[int(len(ts) * 0.99)] * 1000
    print("frames=%d  update+render avg %.3f ms  p99 %.3f ms  max %.3f ms (budget 16.7 ms)"
          % (len(ts), avg, p99, ts[-1] * 1000))


if __name__ == "__main__":
    main()
