#!/usr/bin/env python3
"""World Warrior Dungeon - run with:  python3 main.py   (add --fullscreen for full screen)"""

from sfrogue.game import main

if __name__ == "__main__":
    main()
