
 If you have problems you will need to exclude the files from your antivirus. The easiest way is to download to it's own folder and EXCLUDE the folder. 
 
 https://support.microsoft.com/en-us/windows/add-an-exclusion-to-windows-security-811816c0-4dfd-af4a-47e4-c301afe13b26
 
 1. Select Start  , then open Settings  . Under Privacy & security  , select Virus & threat protection.
 2. Under Virus & threat protection settings, select Manage settings, and then under Exclusions, select Add or remove exclusions.
 3. Select Add an exclusion, and then select from files, folders, file types, or process. A folder exclusion will apply to all subfolders within the folder as well.